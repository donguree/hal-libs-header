#include "hal_sstr.h"

#include <openssl/rand.h>
#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <string.h>
#include <syslog.h>

#define ref_log_info(fmt, args...) syslog(LOG_INFO, fmt, ##args)
#define ref_log_err(fmt, args...) syslog(LOG_ERR, fmt, ##args)

#define MAGIC_CODE_LEN 8
#define DATA_TYPE_LEN 1
#define VERSION_LEN 2
#define VERSION 1

#define SECURE_DATA_HEADER_MAX_LEN 200
#define MAGIC_CODE_SEDATA "sedata__"
#define MAGIC_CODE_PROV_SEDATA "prsedata"
#define HMAC_SIZE 32
#define KEY_SIZE_AES256 32
#define KEY_SIZE_AES128 16
#define IV_SIZE 16
#define AES_BLOCK_SIZE 16
#define AES_MODE_CBC_STR "CBC"
#define AES_MODE_ECB_STR "ECB"
#define KEY_ENCODING_PEM "PEM"
#define KEY_ENCODING_DER "DER"

#define ADD_DATA(data, dataLen) { \
		if (buffLen < (offset + dataLen)) { \
			free(pBuff); \
			return 0; \
		} \
		memcpy(pBuff + offset, data, dataLen); \
		offset += dataLen; \
	}

#define ADD_DATA_AES256_ECB(data, dataLen, key) { \
		int len = 0; \
		if (buffLen < (offset + dataLen)) { \
			free(pBuff); \
			return 0; \
		} \
		if (!_encrypt_AES256_ECB(dataLen, data, &len, pBuff + offset, key)) { \
			free(pBuff); \
			return 0; \
		} \
		offset += len; \
	}

#define ADD_LEN_AND_DATA_AES256_CBC(data, dataLen, key) { \
		int len = 0; \
		uint8_t iv[IV_SIZE] = {0}; \
		uint8_t *pLenPos = pBuff + offset; \
		offset += 4; \
		if (buffLen < (offset + dataLen + 16 + 16)) { \
			free(pBuff); \
			return 0; \
		} \
		_get_random(sizeof(iv), iv); \
		ADD_DATA(iv, sizeof(iv)); \
		if (!_encrypt_AES256_CBC(dataLen, data, &len, pBuff + offset, key, iv)) { \
			free(pBuff); \
			return 0; \
		} \
		offset += len; \
		len += sizeof(iv); \
		memcpy(pLenPos, &len, sizeof(len)); \
	}

#define ADD_HMAC(key) { \
		int len = 0; \
		if (buffLen < (offset + 32)) { \
			free(pBuff); \
			return 0; \
		} \
		if (!_get_HMAC(offset, pBuff, &len, pBuff + offset, key)) { \
			free(pBuff); \
			return 0; \
		} \
		offset += len; \
	}

#define GET_DATA(data, ptr) { memcpy(&data, ptr, sizeof(data)); }

static uint8_t *TA_NAME_SESTORE = "SecureStorage";

// Device Unique Key
uint8_t DUK[KEY_SIZE_AES256] = {
	0x26, 0xa0, 0x9b, 0x6a, 0x30, 0xfb, 0x91, 0xef, 0xba, 0xb0, 0x73, 0xff, 0xd6, 0x8e, 0x58, 0xcb,
	0x8f, 0x81, 0x03, 0x5a, 0xf3, 0xa3, 0xe8, 0x67, 0x60, 0xfb, 0xba, 0x06, 0x5a, 0x98, 0xcb, 0xf2
};

// Device Common Key
uint8_t DCK[KEY_SIZE_AES256] = {
	0xb4, 0x8a, 0xcc, 0x13, 0x47, 0x35, 0x01, 0xcd, 0xd6, 0xc7, 0xc8, 0xc0, 0xf6, 0xde, 0x23, 0x92,
	0x42, 0x6d, 0xe8, 0x39, 0xa6, 0xff, 0xb0, 0x15, 0x0a, 0x91, 0xb1, 0x01, 0x1c, 0x3f, 0xd5, 0x1c
};

// Deivce Commont HMAC Key
uint8_t DCHK[HMAC_SIZE] = {
	0x27, 0xa4, 0x5f, 0x99, 0xed, 0x9b, 0x0a, 0x47, 0x87, 0x53, 0xee, 0x5b, 0x67, 0x59, 0xc3, 0xdc,
	0xc2, 0x9c, 0x1c, 0x03, 0x95, 0xbf, 0x8e, 0x47, 0x8c, 0x04, 0x56, 0xfe, 0x0a, 0x1b, 0x70, 0xfa
};

// playready
uint8_t DCK_PR[KEY_SIZE_AES256] = {
	0x1e, 0xff, 0xd5, 0xd7, 0xa0, 0xbb, 0x16, 0x09, 0x26, 0x02, 0xae, 0x20, 0x21, 0xa1, 0x9a, 0xe5,
	0xdf, 0x12, 0x59, 0x96, 0x0b, 0x28, 0xd0, 0xd3, 0x33, 0x1c, 0x59, 0xc0, 0xbf, 0x2c, 0x93, 0xaf
};

uint8_t DCHK_PR[HMAC_SIZE] = {
	0x18, 0xd0, 0x47, 0xd8, 0x73, 0x17, 0x05, 0x2d, 0x67, 0xad, 0x34, 0x14, 0xcb, 0xf9, 0x36, 0x05,
	0x8f, 0xf6, 0xbf, 0x9f, 0x0b, 0x2f, 0x5d, 0x87, 0x9f, 0x54, 0x18, 0x06, 0xf7, 0xe3, 0x69, 0x20
};

// hdcp
uint8_t DCK_HDCP[KEY_SIZE_AES256] = {
	0xc3, 0x07, 0xc5, 0xb5, 0x11, 0x19, 0xe2, 0xa1, 0x5a, 0x7d, 0x01, 0x2a, 0x36, 0x7b, 0xd0, 0xb4,
	0xb8, 0x9f, 0x35, 0xe4, 0x21, 0xf4, 0x69, 0xfd, 0x63, 0x70, 0x24, 0x70, 0x11, 0x02, 0xb6, 0x3e
};

uint8_t DCHK_HDCP[HMAC_SIZE] = {
	0x4c, 0xde, 0xb6, 0x79, 0x36, 0x41, 0x8d, 0x62, 0x78, 0x29, 0x1e, 0xa6, 0xd8, 0xbc, 0x83, 0x42,
	0x96, 0x68, 0xbf, 0xa0, 0x11, 0x52, 0xfe, 0x26, 0x13, 0x02, 0xb7, 0xdb, 0x58, 0xda, 0x54, 0xd6
};

//acas
uint8_t DCK_ACAS[KEY_SIZE_AES256] = {
	0xe1, 0xe1, 0x98, 0xe4, 0xd9, 0xb7, 0x4f, 0x5c, 0xa9, 0x61, 0x4a, 0x83, 0x19, 0x70, 0x06, 0xab,
	0x6f, 0x0f, 0x4a, 0xaa, 0xe7, 0x68, 0x61, 0x21, 0x64, 0x1e, 0x6f, 0xde, 0xc8, 0x0c, 0x74, 0x89
};

uint8_t DCHK_ACAS[HMAC_SIZE] = {
	0x4e, 0x5d, 0x06, 0xc3, 0x41, 0x0b, 0x76, 0x95, 0x5e, 0x58, 0xa4, 0x3a, 0xf8, 0xde, 0x7d, 0x78,
	0xef, 0x54, 0x78, 0xb3, 0x71, 0x21, 0x71, 0x2c, 0xde, 0x92, 0x07, 0xb0, 0x84, 0xf8, 0x7c, 0xcb
};

//atsc
uint8_t DCK_ATSC[KEY_SIZE_AES256] = {
	0xfb, 0x15, 0xed, 0x18, 0xe2, 0x24, 0x5f, 0x77, 0x08, 0x57, 0xb4, 0x13, 0x5f, 0x90, 0x52, 0x90,
	0x16, 0x8e, 0x19, 0x16, 0xf0, 0x27, 0x76, 0xd9, 0x2f, 0x80, 0xca, 0xd1, 0x02, 0x27, 0x57, 0x94
};

uint8_t DCHK_ATSC[HMAC_SIZE] = {
	0xb5, 0x94, 0x0b, 0x9d, 0x42, 0x48, 0x68, 0x9e, 0x92, 0xf1, 0xf1, 0x5e, 0x38, 0xaf, 0x7d, 0x1a,
	0xb6, 0x69, 0x71, 0x9b, 0xf8, 0xd6, 0x4c, 0xd7, 0xde, 0xaa, 0x6f, 0xe6, 0xf8, 0x73, 0x06, 0x65
};

//ecp
uint8_t DCK_ECP[KEY_SIZE_AES256] = {
	0xa5, 0x13, 0xc8, 0xa9, 0xde, 0x1a, 0x81, 0x8a, 0x24, 0x4c, 0xe7, 0x70, 0xd4, 0xdf, 0x3f, 0x0a,
	0x2f, 0xed, 0x1a, 0xf7, 0xcc, 0x28, 0xa2, 0x98, 0xcd, 0xa2, 0xf6, 0xec, 0xe1, 0xbe, 0xff, 0x41
};

uint8_t DCHK_ECP[HMAC_SIZE] = {
	0xb5, 0xf4, 0x3e, 0x9f, 0x6f, 0x7a, 0x07, 0x62, 0xff, 0xd3, 0xf8, 0x4e, 0xca, 0x86, 0x2d, 0xda,
	0xfb, 0x07, 0x0c, 0x3a, 0x50, 0xbb, 0x71, 0xe0, 0x97, 0x0c, 0x92, 0x86, 0x6f, 0x6b, 0x13, 0x68
};

// keyblob data for test
uint8_t test_keyblob_00[19] = {
	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
	0x10, 0x11, 0x12
};

enum {
	STORAGETYPE_WOS_SESTORE = 1,
	STORAGETYPE_SOC_SESTORE
};

enum {
	DATAFORMAT_SEDATA = 1,
	DATAFORMAT_PROV_SEDATA
};

enum {
	TA_CMD_DEAL_SEDATA,
	TA_CMD_DEAL_GENERAL,
	TA_CMD_READ_SECUREDATA,
	TA_CMD_MAKE_HMAC,
	TA_CMD_VERIFY_HMAC,
	TA_CMD_AES_ENCRYPT,
	TA_CMD_AES_DECRYPT,
	TA_CMD_RSA_ENCRYPT,
	TA_CMD_RSA_DECRYPT
};

enum {
	DECRYPT = 0,
	ENCRYPT
};

enum {
	AES_MODE_CBC,
	AES_MODE_ECB
};

enum {
	NO_PADDING = 0,
	PADDING
};

/*
 * RSA Padding Type
 */
typedef enum {
    HAL_CRYPTO_RSA_NO_PADDING,
    HAL_CRYPTO_RSA_PKCS1_OAEP_PADDING
} HAL_CRYPTO_RSA_PADDING_T;

struct metainfo_sedata {
	uint8_t magic[MAGIC_CODE_LEN];
	uint16_t version;
	uint8_t storageType;
	uint8_t retToRee;
	uint32_t targetTaInfo_len;
	uint8_t *pTargetTaInfo;
	uint32_t interTaInfo_len;
	uint8_t *pInterTaInfo;
	uint32_t keyId_len;
	uint8_t *pKeyId;
	uint32_t keyblob_len;
	uint32_t enc_keyblob_len;
};

static void _hexdump(uint8_t *ptr, int buflen) {
	unsigned char *buf;
	char outbuf[100] = {0,};
	char outbuf_cpy[100] = {0,};
	int i, j;

	if (!ptr)
		return;

	buf = (unsigned char*)ptr;
	for (i=0; i<buflen; i+=16) {
		snprintf(outbuf, 100, "%06x: ", i);
		for (j=0; j<16; j++)
		{
			memcpy(outbuf_cpy, outbuf ,100);
			if (i+j < buflen)
				snprintf(outbuf, 100, "%s%02x", outbuf_cpy, buf[i+j]);
			else
				snprintf(outbuf, 100, "%s  ", outbuf_cpy);
		}
		ref_log_info("%s", outbuf);
		memset(outbuf, 0x0, sizeof(outbuf));
	}
}

static int _dump_sedata(uint32_t nSrcLen, uint8_t *pSrcData) {
	ref_log_info("++ _dump_sedata");

	int offset = 0;
	int dataFormat = 0;
	int len = 0;
	uint8_t magic[MAGIC_CODE_LEN] = {0};

	if (!pSrcData)
		return 0;

	// magic code
	memcpy(magic, pSrcData + offset, MAGIC_CODE_LEN);
	if (!memcmp(MAGIC_CODE_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_SEDATA;
	else if (!memcmp(MAGIC_CODE_PROV_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_PROV_SEDATA;
	else {
		ref_log_err("invalid magic code");
		return 0;
	}

	// magic
	ref_log_info("magic : %.*s", MAGIC_CODE_LEN, pSrcData + offset);
	offset += MAGIC_CODE_LEN;

	// version
	ref_log_info("version : %02X %02X", *(pSrcData + offset), *(pSrcData + offset + 1));
	offset += VERSION_LEN;

	// data type
	ref_log_info("data type : %02X", *(pSrcData + offset));
	offset += DATA_TYPE_LEN;

	// return to REE
	ref_log_info("return to REE : %02X", *(pSrcData + offset));
	offset += 1;

	// target TA info
	GET_DATA(len, pSrcData + offset);
	ref_log_info("target TA info : %.*s, size = %d", len, pSrcData + offset + 4, len);
	offset += (4 + *(uint32_t*)(pSrcData + offset));

	// target inter TA info
	if (dataFormat == DATAFORMAT_SEDATA) {
		GET_DATA(len, pSrcData + offset);
		ref_log_info("inter TA info : %.*s, size = %d", len, pSrcData + offset + 4, len);
		offset += (4 + *(uint32_t*)(pSrcData + offset));
	}

	// Key ID
	GET_DATA(len, pSrcData + offset);
	ref_log_info("Key ID : %.*s, size = %d", len, pSrcData + offset + 4, len);
	offset += (4 + *(uint32_t*)(pSrcData + offset));

	if (dataFormat == DATAFORMAT_PROV_SEDATA) {
		// Keyblob len
		GET_DATA(len, pSrcData + offset);
		ref_log_info("keyblob length : %d", len);
		offset += 4;
	}

	// length of encryted keyblob
	GET_DATA(len, pSrcData + offset);
	ref_log_info("len of encrypted keyblob = %d", len);
	offset += 4;

	// encrypted keyblob
	//ref_log_info("encrypted keyblob :");
	//_hexdump(pSrcData + offset, len);
	offset += len;

	if (dataFormat == DATAFORMAT_PROV_SEDATA) {
		// ENC_DUK{SDEK}
		ref_log_info("ENC_DUK{SDEK} :");
		_hexdump(pSrcData + offset, KEY_SIZE_AES256);
		offset += KEY_SIZE_AES256;
	}

	// HMAC
	ref_log_info("HMAC :");
	_hexdump(pSrcData + offset, HMAC_SIZE);
	offset += HMAC_SIZE;

	ref_log_info("-- _dump_sedata");
	return 1;
}

static int _get_random(int size, uint8_t *pRand)
{
    if(0 == RAND_bytes(pRand, size))
    {
        srand(time(NULL));
        int i=0;
        for(;i<size;i++)
            pRand[i]=rand()%128;
    }
    return 1;
}

static int _aes_crypt(const int nSrcLen, const uint8_t *pSrcData,
					int *pnDstLen, uint8_t *pDstData,
					const uint32_t nKeyLen, const uint8_t *pKey, const uint8_t *iv,
    				int mode, int enc, int padding) { // enc: 1 if encrypting, 0 if decrypting.
	EVP_CIPHER_CTX *ctx = NULL;
	int len = *pnDstLen;
	EVP_CIPHER *pEvp_cipher = NULL;

	if (!pSrcData || !pnDstLen || !pDstData || !pKey) {
		ref_log_err("null parameter");
		return 0;
	}

	if (nKeyLen == KEY_SIZE_AES256) {
		if (mode == AES_MODE_CBC)
			pEvp_cipher = EVP_aes_256_cbc();
		if (mode == AES_MODE_ECB)
			pEvp_cipher = EVP_aes_256_ecb();
	}
	else if (nKeyLen == KEY_SIZE_AES128) {
		if (mode == AES_MODE_CBC)
			pEvp_cipher = EVP_aes_128_cbc();
		if (mode == AES_MODE_ECB)
			pEvp_cipher = EVP_aes_128_ecb();
	}
	else {
		ref_log_err("invalid key size");
		return 0;
	}

	if(!(ctx = EVP_CIPHER_CTX_new())) {
		ref_log_err("EVP_CIPHER_CTX_new failed");
		return 0;
	}

	if (!EVP_CipherInit_ex(ctx, pEvp_cipher, NULL, pKey, iv, enc)) {
		ref_log_err("EVP_CipherInit_ex failed");
		EVP_CIPHER_CTX_free(ctx);
		return 0;
	}

	if (padding == NO_PADDING)
		EVP_CIPHER_CTX_set_padding(ctx, 0);

	if (!EVP_CipherUpdate(ctx, pDstData, &len, pSrcData, nSrcLen)) {
		ref_log_err("EVP_CipherUpdate failed");
		EVP_CIPHER_CTX_free(ctx);
		return 0;
	}
	*pnDstLen = len;

	if (!EVP_CipherFinal_ex(ctx, pDstData + *pnDstLen, &len)) {
		ref_log_err("EVP_CipherFinal_ex failed");
		EVP_CIPHER_CTX_free(ctx);
		return 0;
	}
	*pnDstLen += len;

	EVP_CIPHER_CTX_free(ctx);

	return 1;
}

static int _encrypt_AES256_CBC(int nSrcLen, uint8_t *pSrcData,
							int *pnDstLen, uint8_t *pDstData,
							uint8_t *pKey, uint8_t *iv) {
	return _aes_crypt(nSrcLen, pSrcData, pnDstLen, pDstData, KEY_SIZE_AES256, pKey, iv, AES_MODE_CBC, ENCRYPT, PADDING);
}

static int _decrypt_AES256_CBC(int nSrcLen, uint8_t *pSrcData,
							int *pnDstLen, uint8_t *pDstData,
							uint8_t *pKey, uint8_t *iv) {
	return _aes_crypt(nSrcLen, pSrcData, pnDstLen, pDstData, KEY_SIZE_AES256, pKey, iv, AES_MODE_CBC, DECRYPT, PADDING);
}

static int _encrypt_AES256_ECB(int nSrcLen, uint8_t *pSrcData,
							int *pnDstLen, uint8_t *pDstData,
							uint8_t *pKey) {
	return _aes_crypt(nSrcLen, pSrcData, pnDstLen, pDstData, KEY_SIZE_AES256, pKey, NULL, AES_MODE_ECB, ENCRYPT, NO_PADDING);
}

static int _decrypt_AES256_ECB(int nSrcLen, uint8_t *pSrcData,
							int *pnDstLen, uint8_t *pDstData,
							uint8_t *pKey) {
	return _aes_crypt(nSrcLen, pSrcData, pnDstLen, pDstData, KEY_SIZE_AES256, pKey, NULL, AES_MODE_ECB, DECRYPT, NO_PADDING);
}

static int _get_HMAC(size_t nMsgLen, const uint8_t *pMsg, size_t *pnHmacLen, uint8_t *pHmacValue, uint8_t *pKey) {
	EVP_MD_CTX* ctx = NULL;
	EVP_PKEY *pEvpKey = NULL;

	if(!pMsg || !nMsgLen || !pnHmacLen || !pKey)
		return 0;

	ctx = EVP_MD_CTX_new();
	if (ctx == NULL) {
		return 0;
	}

	if(!(pEvpKey = EVP_PKEY_new_mac_key(EVP_PKEY_HMAC, NULL, pKey, 32))) {
		EVP_MD_CTX_free(ctx);
		return 0;
	}

	if (!EVP_DigestSignInit(ctx, NULL, EVP_sha256(), NULL, pEvpKey)) {
		EVP_PKEY_free(pEvpKey);
		EVP_MD_CTX_free(ctx);
		return 0;
	}

	if (!EVP_DigestSignUpdate(ctx, pMsg, nMsgLen)) {
		EVP_PKEY_free(pEvpKey);
		EVP_MD_CTX_free(ctx);
		return 0;
	}

	if (!EVP_DigestSignFinal(ctx, pHmacValue, pnHmacLen)) {
		EVP_PKEY_free(pEvpKey);
		EVP_MD_CTX_free(ctx);
		return 0;
	}

	EVP_PKEY_free(pEvpKey);
	EVP_MD_CTX_free(ctx);

	return 1;
}

static int _verify_HMAC(size_t nMsgLen, const uint8_t *pMsg, size_t nHmacLen, const uint8_t *pHmacValue, uint8_t *pKey)
{
    uint8_t buff[EVP_MAX_MD_SIZE];
    size_t buffLen;

    if(!pMsg || !nMsgLen || !pHmacValue || !nHmacLen || !pKey)
        return 0;

	if (!_get_HMAC(nMsgLen, pMsg, &buffLen, buff, pKey)) {
		return 0;
	}

    return (nHmacLen == buffLen) && (memcmp(pHmacValue, buff, buffLen) == 0);
}

static int _verify_integrity_sedata(uint8_t *dchk, uint32_t nSrcLen, uint8_t *pSrcData) {
	ref_log_info("++ _verify_integrity_sedata");

	int offset = 0;
	int dataFormat = 0;
	int len = 0;
	uint8_t magic[MAGIC_CODE_LEN] = {0};
	uint8_t HmacKey[HMAC_SIZE] = {0};

	if (!pSrcData) {
		ref_log_err("null parameter");
		return 0;
	}

	// magic code
	memcpy(magic, pSrcData, MAGIC_CODE_LEN);
	if (!memcmp(MAGIC_CODE_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_SEDATA;
	else if (!memcmp(MAGIC_CODE_PROV_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_PROV_SEDATA;
	else {
		ref_log_err("invalid magic code");
		return 0;
	}

	// skip magic + version + data type + return to REE
	offset += MAGIC_CODE_LEN + VERSION_LEN + DATA_TYPE_LEN + 1;

	// skip target TA info
	GET_DATA(len, pSrcData + offset);
	offset += (4 + len);

	// skip target inter TA info
	if (dataFormat == DATAFORMAT_SEDATA) {
		GET_DATA(len, pSrcData + offset);
		offset += (4 + len);
	}

	// skip Key ID
	GET_DATA(len, pSrcData + offset);
	offset += (4 + len);

	if (dataFormat == DATAFORMAT_PROV_SEDATA) {
		// skip keyblob length
		offset += 4;
	}

	// skip encrypted keyblob
	GET_DATA(len, pSrcData + offset);
	offset += (4 + len);

	if (dataFormat == DATAFORMAT_PROV_SEDATA) {
		// skip Enc key
		offset += KEY_SIZE_AES256;
	}

	// set HMAC key
	if (dataFormat == DATAFORMAT_SEDATA) {
		if (dchk)
			memcpy(HmacKey, dchk, HMAC_SIZE);
		else {
			ref_log_err("dchk is null");
			return 0;
		}
	}
	else {
		if (offset + HMAC_SIZE > nSrcLen) {
			ref_log_err("invalid format");
			return 0;
		}
		len = sizeof(HmacKey);
		if (!_decrypt_AES256_ECB(HMAC_SIZE, pSrcData + offset, &len, HmacKey, DUK)) {
			ref_log_err("failed to get hmac key");
			return 0;
		}
		offset += HMAC_SIZE;
	}

	if (offset + HMAC_SIZE > nSrcLen) {
		ref_log_err("invalid format");
		return 0;
	}
	// validate HMAC
	if (!_verify_HMAC(offset, pSrcData, HMAC_SIZE, pSrcData + offset, HmacKey)) {
		ref_log_err("failed to verify HMAC value");
		_dump_sedata(nSrcLen,  pSrcData);
		return 0;
	}

	ref_log_info("-- _verify_integrity_sedata");
	return 1;
}

static int _get_keyblob(uint8_t *dck, uint32_t nSrcLen, uint8_t *pSrcData, uint32_t *pKeyblobLen, uint8_t **ppKeyblob) {
	ref_log_info("++ _get_keyblob");

	int offset = 0;
	int dataFormat = 0;
	uint8_t magic[MAGIC_CODE_LEN] = {0};
	uint8_t HmacKey[HMAC_SIZE] = {0};
	uint8_t EncKey[KEY_SIZE_AES256] = {0};
	uint8_t *pBuf = NULL;
	int nBufLen = 0;
	int len = 0;
	uint8_t *iv = NULL;
	uint8_t *pEncKeyblob = NULL;
	int nEncKeyblobLen = 0;

	if (!pSrcData || !pKeyblobLen || !ppKeyblob) {
		ref_log_err("null parameter");
		return 0;
	}

	// magic code
	memcpy(magic, pSrcData + offset, MAGIC_CODE_LEN);
	if (!memcmp(MAGIC_CODE_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_SEDATA;
	else if (!memcmp(MAGIC_CODE_PROV_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_PROV_SEDATA;
	else {
		ref_log_err("invalid magic code");
		return 0;
	}

	// skip magic + version + data type + return to REE
	offset += MAGIC_CODE_LEN + VERSION_LEN + DATA_TYPE_LEN + 1;

	// skip target TA info
	GET_DATA(len, pSrcData + offset);
	offset += (4 + len);

	// skip target inter TA info
	if (dataFormat == DATAFORMAT_SEDATA) {
		GET_DATA(len, pSrcData + offset);
		offset += (4 + len);
	}

	// skip Key ID
	GET_DATA(len, pSrcData + offset);
	offset += (4 + len);

	if (dataFormat == DATAFORMAT_PROV_SEDATA) {
		// skip keyblob length
		offset += 4;
	}

	// length of encryted keyblob
	GET_DATA(len, pSrcData + offset);
	nEncKeyblobLen = len;
	offset += 4;

	// IV, encrypted keyblob
	iv = pSrcData + offset;
	offset += IV_SIZE;

	pEncKeyblob = pSrcData + offset;
	offset += (nEncKeyblobLen - IV_SIZE);

	// set Enc key
	if (dataFormat == DATAFORMAT_SEDATA) {
		if (dck)
			memcpy(EncKey, dck, KEY_SIZE_AES256);
		else {
			ref_log_err("dck is null");
			return 0;
		}
	}
	else {
		len = sizeof(EncKey);
		if (!_decrypt_AES256_ECB(KEY_SIZE_AES256, pSrcData + offset, &len, EncKey, DUK)) {
			ref_log_err("failed to get enc key");
			return 0;
		}
		offset += KEY_SIZE_AES256;
	}

	pBuf = calloc(nEncKeyblobLen, 1);
	if (!pBuf) {
		ref_log_err("failed to allocate memory");
		return 0;
	}

	// decrypt keyblob
	if (!_decrypt_AES256_CBC(nEncKeyblobLen - IV_SIZE,	 pEncKeyblob, &nBufLen, pBuf, EncKey, iv)) {
		free(pBuf);
		ref_log_err("failed to decrypt keyblob");
		return 0;
	}

	//ref_log_info("keyblob (size = %d):", nBufLen);
	//_hexdump(pBuf, nBufLen);

	*pKeyblobLen = nBufLen;
	*ppKeyblob = pBuf;

	ref_log_info("-- _get_keyblob");
	return 1;
}

static void _metainfo_init(struct metainfo_sedata* pMeta) {
	if (!pMeta)
		return;

	memset(pMeta, 0, sizeof(struct metainfo_sedata));
}

static void _metainfo_free(struct metainfo_sedata* pMeta) {
	if (!pMeta)
		return;

	if (pMeta->pTargetTaInfo) {
		free(pMeta->pTargetTaInfo);
		pMeta->pTargetTaInfo = NULL;
	}

	if (pMeta->pInterTaInfo) {
		free(pMeta->pInterTaInfo);
		pMeta->pInterTaInfo = NULL;
	}

	if (pMeta->pKeyId) {
		free(pMeta->pKeyId);
		pMeta->pKeyId = NULL;
	}

	memset(pMeta, 0, sizeof(struct metainfo_sedata));
}

static int _parse_metainfo(uint32_t nSrcLen, uint8_t *pSrcData, struct metainfo_sedata* pMeta) {
	ref_log_info("++ _parse_metainfo");

	int offset = 0;
	int dataFormat = 0;
	int len = 0;
	uint8_t magic[MAGIC_CODE_LEN] = {0};

	if (!pSrcData || !pMeta) {
		ref_log_err("null parameter");
		return 0;
	}

	// magic code
	memcpy(magic, pSrcData + offset, MAGIC_CODE_LEN);
	if (!memcmp(MAGIC_CODE_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_SEDATA;
	else if (!memcmp(MAGIC_CODE_PROV_SEDATA, magic, MAGIC_CODE_LEN))
		dataFormat = DATAFORMAT_PROV_SEDATA;
	else {
		ref_log_err("invalid magic code");
		return 0;
	}

	// magic
	memcpy(pMeta->magic, magic, sizeof(magic));
	//ref_log_info("magic : %.*s", MAGIC_CODE_LEN, pSrcData + offset);
	offset += MAGIC_CODE_LEN;

	// version
	GET_DATA(pMeta->version, pSrcData + offset);
	//ref_log_info("version : %02X %02X", *(pSrcData + offset), *(pSrcData + offset + 1));
	offset += VERSION_LEN;

	// data type
	pMeta->storageType = *(pSrcData + offset);
	//ref_log_info("data type : %02X", *(pSrcData + offset));
	offset += DATA_TYPE_LEN;

	// check if storage type is available
	if (pMeta->storageType != STORAGETYPE_WOS_SESTORE && pMeta->storageType != STORAGETYPE_SOC_SESTORE) {
		ref_log_err("invalid storage type");
		_metainfo_free(pMeta);
		return 0;
	}

	// return to REE
	pMeta->retToRee = *(pSrcData + offset);
	//ref_log_info("return to REE : %02X", *(pSrcData + offset));
	offset += 1;

	// target TA info
	GET_DATA(pMeta->targetTaInfo_len, pSrcData + offset);
	if (pMeta->targetTaInfo_len) {
		pMeta->pTargetTaInfo = calloc(pMeta->targetTaInfo_len, 1);
		if (!pMeta->pTargetTaInfo) {
			_metainfo_free(pMeta);
			return 0;
		}
		memcpy(pMeta->pTargetTaInfo, pSrcData + offset + 4, pMeta->targetTaInfo_len);
	}
	//ref_log_info("target TA info : %.*s, size = %d", *(uint32_t*)(pSrcData + offset), pSrcData + offset + 4, *(uint32_t*)(pSrcData + offset));
	offset += (4 + pMeta->targetTaInfo_len);

	// target inter TA info
	if (dataFormat == DATAFORMAT_SEDATA) {
		GET_DATA(pMeta->interTaInfo_len, pSrcData + offset);
		if (pMeta->interTaInfo_len) {
			pMeta->pInterTaInfo = calloc(pMeta->interTaInfo_len, 1);
			if (!pMeta->pInterTaInfo) {
				_metainfo_free(pMeta);
				return 0;
			}
			memcpy(pMeta->pInterTaInfo, pSrcData + offset + 4, pMeta->interTaInfo_len);
		}
		//ref_log_info("inter TA info : %.*s, size = %d", *(uint32_t*)(pSrcData + offset), pSrcData + offset + 4, *(uint32_t*)(pSrcData + offset));
		offset += (4 + pMeta->interTaInfo_len);
	}

	// Key ID
	GET_DATA(pMeta->keyId_len, pSrcData + offset);
	if (pMeta->keyId_len) {
		pMeta->pKeyId = calloc(pMeta->keyId_len, 1);
		if (!pMeta->pKeyId) {
			_metainfo_free(pMeta);
			return 0;
		}
		memcpy(pMeta->pKeyId, pSrcData + offset + 4, pMeta->keyId_len);
	}
	//ref_log_info("Key ID : %.*s, size = %d", *(uint32_t*)(pSrcData + offset), pSrcData + offset + 4, *(uint32_t*)(pSrcData + offset));
	offset += (4 + pMeta->keyId_len);

	if (dataFormat == DATAFORMAT_PROV_SEDATA) {
		// keyblob length
		GET_DATA(pMeta->keyblob_len, pSrcData + offset);
		offset += 4;
	}

	// length of encrypted keyblob
	GET_DATA(pMeta->enc_keyblob_len, pSrcData + offset);
	offset += 4;

	ref_log_info("-- _parse_metainfo");
	return 1;
}

static int _compose_securedata(struct metainfo_sedata *pMeta, uint32_t keyblob_len, uint8_t *pKeyblob, uint32_t *pDstLen, uint8_t *pDstData) {
	uint8_t *pBuff = NULL;
	int buffLen = SECURE_DATA_HEADER_MAX_LEN + keyblob_len;
	int offset = 0;
	uint8_t SDEK[KEY_SIZE_AES256] = {0};
	uint8_t HMacKey[HMAC_SIZE] = {0};

	if (!pMeta || !pKeyblob || !pDstLen) {
		ref_log_err("null parameter");
		return 0;
	}

	pBuff = calloc(buffLen, sizeof(uint8_t));
	if (!pBuff) {
		ref_log_err("failed to allocate memory for pBuff(%d)", buffLen);
		return 0;
	}

	// magic code (8)
	ADD_DATA(pMeta->magic, sizeof(pMeta->magic));

	// version (2)
	ADD_DATA(&pMeta->version, sizeof(pMeta->version));

	// data type (1)
	ADD_DATA(&pMeta->storageType, sizeof(pMeta->storageType));

	// return to REE (1)
	ADD_DATA(&pMeta->retToRee, sizeof(pMeta->retToRee));

	// len of target TA info (4)
	ADD_DATA(&pMeta->targetTaInfo_len, sizeof(pMeta->targetTaInfo_len));
	if (pMeta->targetTaInfo_len)
		ADD_DATA(pMeta->pTargetTaInfo, pMeta->targetTaInfo_len);

	// len of Key ID (4)
	ADD_DATA(&pMeta->keyId_len, sizeof(pMeta->keyId_len));
	if (pMeta->keyId_len)
		ADD_DATA(pMeta->pKeyId, pMeta->keyId_len);

	// generate a SDEK randomly
	_get_random(sizeof(SDEK), SDEK);

	// len of msg (4)
	ADD_DATA(&keyblob_len, sizeof(keyblob_len));

	// len | (IV | encrypted msg)
	ADD_LEN_AND_DATA_AES256_CBC(pKeyblob, keyblob_len, SDEK);

	// encrypt SDEK with DUK(Device Unique Key) : AES256-ECB
	ADD_DATA_AES256_ECB(SDEK, sizeof(SDEK), DUK);

	// generate HMAC key
	_get_random(sizeof(HMacKey), HMacKey);

	// encrypt HMAC with DUK
	ADD_DATA_AES256_ECB(HMacKey, sizeof(HMacKey), DUK);

	// HMAC value (32)
	ADD_HMAC(HMacKey);

	if (*pDstLen < offset) {
		ref_log_err("not enough dst len(%d, %d)", *pDstLen, offset);
		free(pBuff);
		return 0;
	}

	*pDstLen = offset;
	memcpy(pDstData, pBuff, *pDstLen);
	free(pBuff);

	ref_log_info("composed(len=%d)", *pDstLen);

	return 1;
}

static int _verify_and_get_key_sedata(uint8_t *dck, uint8_t *dchk,
								uint32_t nSeDataLen, uint8_t *pSeData,
								uint32_t *pKeyLen, uint8_t **ppKey, int isSpecificTA) {
	uint8_t *pKeyblob = NULL;
	uint32_t nKeyblobLen = 0;
	struct metainfo_sedata metainfo;

	if (!dck || !dchk || !pSeData || !pKeyLen || !ppKey) {
		ref_log_err("null parameter");
		return 0;
	}

	// check HMAC for integrity
	if (!_verify_integrity_sedata(dchk, nSeDataLen, pSeData)) {
		ref_log_err("failed at integrity check");
		return 0;
	}

	// parsing meta info of sedata
	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSeDataLen, pSeData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		return 0;
	}

	// check meta info
	// check magic code
	if (memcmp(metainfo.magic, MAGIC_CODE_SEDATA, MAGIC_CODE_LEN)) {
		ref_log_err("invalid magic code");
		_metainfo_free(&metainfo);
		return 0;
	}

	if (isSpecificTA && metainfo.storageType != STORAGETYPE_SOC_SESTORE) {
		ref_log_err("invalid storage type");
		_metainfo_free(&metainfo);
		return 0;
	}

	if (metainfo.storageType == STORAGETYPE_WOS_SESTORE) {
		if (metainfo.interTaInfo_len) {
			ref_log_err("Not allow to share the key through inter-TA");
			_metainfo_free(&metainfo);
			return 0;
		}
	}
	else if(metainfo.storageType == STORAGETYPE_SOC_SESTORE) {
		if (isSpecificTA && metainfo.retToRee) {
			ref_log_err("Not allow to return plain text key to REE");
			_metainfo_free(&metainfo);
			return 0;
		}

		if (isSpecificTA && metainfo.interTaInfo_len) {
			ref_log_err("Not allow to share the key through inter-TA");
			_metainfo_free(&metainfo);
			return 0;
		}
	}
	else {
		ref_log_err("invalid storage type");
		_metainfo_free(&metainfo);
		return 0;
	}

	_metainfo_free(&metainfo);

	// decrypt keyblob
	if (!_get_keyblob(dck, nSeDataLen, pSeData, &nKeyblobLen, &pKeyblob)) {
		ref_log_err("failed to get keyblob");
		return 0;
	}

	*pKeyLen = nKeyblobLen;
	*ppKey = pKeyblob;

	return 1;
}

static int _verify_and_get_key(uint32_t nSeDataLen, uint8_t *pSeData, uint32_t *pKeyLen, uint8_t **ppKey, int check_return_to_REE) {
	uint8_t *pKeyblob = NULL;
	uint32_t nKeyblobLen = 0;
	struct metainfo_sedata metainfo;

	if (!pSeData || !pKeyLen || !ppKey) {
		ref_log_err("null parameter");
		return 0;
	}

	// check HMAC for integrity
	if (!_verify_integrity_sedata(NULL, nSeDataLen, pSeData)) {
		ref_log_err("failed at integrity check");
		return 0;
	}

	// parsing meta info of sedata
	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSeDataLen, pSeData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		return 0;
	}

	// check meta info
	// check magic code
	if (memcmp(metainfo.magic, MAGIC_CODE_PROV_SEDATA, MAGIC_CODE_LEN)) {
		ref_log_err("invalid magic code");
		_metainfo_free(&metainfo);
		return 0;
	}

	// check storage type
	if (metainfo.storageType != STORAGETYPE_WOS_SESTORE) {
		ref_log_err("invalid storage type");
		_metainfo_free(&metainfo);
		return 0;
	}

	// check if it is allowed to return raw data to REE
	if (check_return_to_REE && metainfo.retToRee != 1) {
		ref_log_err("not allowed to return raw data to REE");
		_metainfo_free(&metainfo);
		return 0;
	}

	_metainfo_free(&metainfo);

	// decrypt keyblob
	if (!_get_keyblob(NULL, nSeDataLen, pSeData, &nKeyblobLen, &pKeyblob)) {
		ref_log_err("failed to get keyblob");
		return 0;
	}

	*pKeyLen = nKeyblobLen;
	*ppKey = pKeyblob;

	return 1;
}

static RSA * _create_rsa(uint8_t *pKey, uint32_t key_len, char *pszKeyType, int isPublicKey)
{
    RSA *rsa = NULL;

	if (!pKey || !pszKeyType) {
		ref_log_err("null parameter");
		return 0;
	}

	if (!memcmp(pszKeyType, KEY_ENCODING_PEM, strlen(KEY_ENCODING_PEM))) {
		if (isPublicKey) {
			BIO *keybio = NULL;

			keybio = BIO_new_mem_buf(pKey, key_len);
			if (keybio == NULL) {
				ref_log_err("failed to create BIO");
				return NULL;
			}

			rsa = PEM_read_bio_RSAPublicKey(keybio, NULL, NULL, NULL);
			BIO_free(keybio);
		}

		if (!rsa) {
			BIO *keybio = NULL;

			keybio = BIO_new_mem_buf(pKey, key_len);
			if (keybio == NULL) {
				ref_log_err("failed to create BIO");
				return NULL;
			}

			rsa = PEM_read_bio_RSAPrivateKey(keybio, NULL, NULL, NULL);
			BIO_free(keybio);
		}
	}
	else if (!memcmp(pszKeyType, KEY_ENCODING_DER, strlen(KEY_ENCODING_DER))) {
		if (isPublicKey) {
			rsa = d2i_RSAPublicKey(NULL, &pKey, key_len);
		}

		if (!rsa) {
			EVP_PKEY *evp_pkey = d2i_PrivateKey(EVP_PKEY_RSA, NULL, &pKey, key_len);
			if ( evp_pkey == NULL )
				return NULL;

			rsa = EVP_PKEY_get1_RSA(evp_pkey);
			EVP_PKEY_free(evp_pkey);
		}
	}
	else {
		ref_log_err("invalid encoding type");
		return NULL;
	}

	return rsa;
}

static uint32_t _get_len_of_securedata(uint32_t target_ta_info_len, uint32_t key_id_len, uint32_t encrypted_keyblob_len) {
	uint32_t len = 0;

	// magic + version + data type + return to REE
	len += MAGIC_CODE_LEN + VERSION_LEN + DATA_TYPE_LEN + 1;

	// target TA info
	len += 4 + target_ta_info_len;

	// Key ID (len=0, data=null)
	len += 4 + key_id_len;

	// SDEK
	len += KEY_SIZE_AES256;

	// keyblob length
	len += 4;

	// len of encrypted keyblob
	len += 4;

	// IV + encrypted keyblob
	len += encrypted_keyblob_len;

	// SDHK
	len += KEY_SIZE_AES256;

	// HMAC
	len += HMAC_SIZE;

	return len;
}

static int secureStorage_TA_sedata(uint32_t nSrcLen, uint8_t *pSrcData, uint32_t *pDstLen, uint8_t *pDstData, int cmd) {
	ref_log_info("cmd = %d", cmd);

	if (cmd == TA_CMD_DEAL_GENERAL) {
		struct metainfo_sedata metainfo;

		_metainfo_init(&metainfo);

		// magic code (8)
		memcpy(metainfo.magic, MAGIC_CODE_PROV_SEDATA, strlen(MAGIC_CODE_PROV_SEDATA));

		// version (2)
		metainfo.version = VERSION;

		// data type (1)
		metainfo.storageType = STORAGETYPE_WOS_SESTORE;

		// return to REE (1)
		metainfo.retToRee = 1;

		// target TA info
		metainfo.targetTaInfo_len = strlen(TA_NAME_SESTORE);
		metainfo.pTargetTaInfo = calloc(metainfo.targetTaInfo_len, 1);
		if (!metainfo.pTargetTaInfo) {
			ref_log_err("failed to allocate memory");
			_metainfo_free(&metainfo);
			return 0;
		}
		memcpy(metainfo.pTargetTaInfo, TA_NAME_SESTORE, metainfo.targetTaInfo_len);

		if (!_compose_securedata(&metainfo,  nSrcLen, pSrcData, pDstLen, pDstData)) {
			ref_log_err("failed to compose a secure data");
			_metainfo_free(&metainfo);
			return 0;
		}

		_metainfo_free(&metainfo);
	}
	else if (cmd == TA_CMD_DEAL_SEDATA) {
		uint8_t *pKeyblob = NULL;
		uint32_t nKeyblobLen = 0;
		struct metainfo_sedata metainfo;

		if(!_verify_and_get_key_sedata(DCK,  DCHK, nSrcLen, pSrcData, &nKeyblobLen, &pKeyblob, 0)) {
			ref_log_err("_verify_and_get_key_sedata failed");
			return 0;
		}

		// parsing meta info of sedata
		_metainfo_init(&metainfo);
		if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
			ref_log_err("failed to parse metainfo");
			free(pKeyblob);
			return 0;
		}

		if (metainfo.storageType == STORAGETYPE_SOC_SESTORE) {
			// store data (keyblob, Return to REE info, Key ID, inter TA info) securely on SFS
			ref_log_info("Return to REE info: %d", metainfo.retToRee);
			ref_log_info("Key ID : %.*s, size = %d", metainfo.keyId_len, metainfo.pKeyId, metainfo.keyId_len);
			ref_log_info("inter TA info : %.*s, size = %d", metainfo.interTaInfo_len, metainfo.pInterTaInfo, metainfo.interTaInfo_len);
		}
		else { //STORAGETYPE_WOS_SESTORE
			// set magic code as provisioned sedata
			memcpy(metainfo.magic, MAGIC_CODE_PROV_SEDATA, MAGIC_CODE_LEN);

			// make a secure data
			if (!_compose_securedata(&metainfo,  nKeyblobLen, pKeyblob, pDstLen, pDstData)) {
				ref_log_err("failed to compose a secure data");
				_metainfo_free(&metainfo);
				free(pKeyblob);
				return 0;
			}
		}

		_metainfo_free(&metainfo);
		free(pKeyblob);
	}
	else if (cmd == TA_CMD_READ_SECUREDATA) {
		uint8_t *pKeyblob = NULL;
		uint32_t nKeyblobLen = 0;

		if (!pDstLen) {
			ref_log_err("null parameter");
			return 0;
		}

		if (!_verify_and_get_key(nSrcLen, pSrcData, &nKeyblobLen, &pKeyblob, 1)) {
			return 0;
		}

		if (*pDstLen < nKeyblobLen) {
			ref_log_err("pDstLen is no enough size(%d < %d)", *pDstLen, nKeyblobLen);
			free(pKeyblob);
			return 0;
		}

		*pDstLen = nKeyblobLen;
		memcpy(pDstData, pKeyblob, nKeyblobLen);
		free(pKeyblob);
	}
	else {
		ref_log_err("invalid cmd");
		return 0;
	}

	ref_log_info("done");

	return 1;
}

static int playready_TA_sedata(uint32_t nSrcLen, uint8_t *pSrcData) {
	uint8_t *pKeyblob = NULL;
	uint32_t nKeyblobLen = 0;
	struct metainfo_sedata metainfo;

	if(!_verify_and_get_key_sedata(DCK_PR,   DCHK_PR, nSrcLen, pSrcData, &nKeyblobLen, &pKeyblob, 1)) {
		ref_log_err("_verify_and_get_key_sedata failed");
		return 0;
	}

	// parsing meta info of sedata
	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		free(pKeyblob);
		return 0;
	}

	// store data (keyblob, Key ID) securely on SFS
	ref_log_info("Key ID : %.*s, size = %d", metainfo.keyId_len, metainfo.pKeyId, metainfo.keyId_len);

	_metainfo_free(&metainfo);
	free(pKeyblob);

	ref_log_info("done");

	return 1;
}

static int hdcp_TA_sedata(uint32_t nSrcLen, uint8_t *pSrcData) {
	uint8_t *pKeyblob = NULL;
	uint32_t nKeyblobLen = 0;
	struct metainfo_sedata metainfo;

	if(!_verify_and_get_key_sedata(DCK_HDCP,    DCHK_HDCP, nSrcLen, pSrcData, &nKeyblobLen, &pKeyblob, 1)) {
		ref_log_info("_verify_and_get_key_sedata failed");
		return 0;
	}

	// parsing meta info of sedata
	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		free(pKeyblob);
		return 0;
	}

	// store data (keyblob, Key ID) securely on SFS
	ref_log_info("Key ID : %.*s, size = %d", metainfo.keyId_len, metainfo.pKeyId, metainfo.keyId_len);

	_metainfo_free(&metainfo);
	free(pKeyblob);

	ref_log_info("done");

	return 1;
}

static int acas_TA_sedata(uint32_t nSrcLen, uint8_t *pSrcData) {
	uint8_t *pKeyblob = NULL;
	uint32_t nKeyblobLen = 0;
	struct metainfo_sedata metainfo;

	if(!_verify_and_get_key_sedata(DCK_ACAS,    DCHK_ACAS, nSrcLen, pSrcData, &nKeyblobLen, &pKeyblob, 1)) {
		ref_log_err("_verify_and_get_key_sedata failed");
		return 0;
	}

	// parsing meta info of sedata
	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		free(pKeyblob);
		return 0;
	}

	// store data (keyblob, Key ID) securely on SFS
	ref_log_info("Key ID : %.*s, size = %d", metainfo.keyId_len, metainfo.pKeyId, metainfo.keyId_len);

	_metainfo_free(&metainfo);
	free(pKeyblob);

	ref_log_info("done");

	return 1;
}

static int atsc_TA_sedata(uint32_t nSrcLen, uint8_t *pSrcData) {
	uint8_t *pKeyblob = NULL;
	uint32_t nKeyblobLen = 0;
	struct metainfo_sedata metainfo;

	if(!_verify_and_get_key_sedata(DCK_ATSC,    DCHK_ATSC, nSrcLen, pSrcData, &nKeyblobLen, &pKeyblob, 1)) {
		ref_log_err("_verify_and_get_key_sedata failed");
		return 0;
	}

	// parsing meta info of sedata
	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		free(pKeyblob);
		return 0;
	}

	// store data (keyblob, Key ID) securely on SFS
	ref_log_info("Key ID : %.*s, size = %d", metainfo.keyId_len, metainfo.pKeyId, metainfo.keyId_len);

	_metainfo_free(&metainfo);
	free(pKeyblob);

	ref_log_info("done");

	return 1;
}

static int ecp_TA_sedata(uint32_t nSrcLen, uint8_t *pSrcData) {
	uint8_t *pKeyblob = NULL;
	uint32_t nKeyblobLen = 0;
	struct metainfo_sedata metainfo;

	if(!_verify_and_get_key_sedata(DCK_ECP,    DCHK_ECP, nSrcLen, pSrcData, &nKeyblobLen, &pKeyblob, 1)) {
		ref_log_err("_verify_and_get_key_sedata failed");
		return 0;
	}

	// parsing meta info of sedata
	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		free(pKeyblob);
		return 0;
	}

	// store data (keyblob, Key ID) securely on SFS
	ref_log_info("Key ID : %.*s, size = %d", metainfo.keyId_len, metainfo.pKeyId, metainfo.keyId_len);

	_metainfo_free(&metainfo);
	free(pKeyblob);

	ref_log_info("done");

	return 1;
}

static int secureStorage_TA_hmac(uint32_t nDataSize, uint8_t *pData, uint8_t *pKey, uint8_t *pHMAC, int cmd) {
	uint8_t HMacKey[HMAC_SIZE] = {0};
	size_t len = 0;

	if (cmd == TA_CMD_MAKE_HMAC) {
		uint8_t EncryptedHMacKey[HMAC_SIZE] = {0};
		uint8_t HMacValue[HMAC_SIZE] = {0};

		// generate HMAC key
		_get_random(sizeof(HMacKey), HMacKey);

		// get HMAC value
		if (!_get_HMAC(nDataSize, pData, &len, HMacValue, HMacKey)) {
			ref_log_err("failed to get hmac");
			return 0;
		}

		// encrypt HMAC key with DUK
		if (!_encrypt_AES256_ECB(sizeof(HMacKey), HMacKey, &len, EncryptedHMacKey, DUK)) {
			ref_log_err("failed to encrypt hmac key");
			return 0;
		}

		memcpy(pKey, EncryptedHMacKey, sizeof(EncryptedHMacKey));
		memcpy(pHMAC, HMacValue, sizeof(HMacValue));
	}
	else if (cmd == TA_CMD_VERIFY_HMAC) {
		// decrypt HMAC key with DUK
		if (!_decrypt_AES256_ECB(HMAC_SIZE, pKey, &len, HMacKey, DUK)) {
			ref_log_err("failed to decrypt hmac key");
			return 0;
		}

		// compare HMAC values
		if (!_verify_HMAC(nDataSize, pData, HMAC_SIZE, pHMAC, HMacKey)) {
			ref_log_err("failed to valify HMAC value");
			return 0;
		}
	}
	else {
		ref_log_err("invalid cmd");
		return 0;
	}

	return 1;
}

// HAL SSTR
HAL_SSTR_R_T ref_HAL_SSTR_MakeSecureData(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData, char *pszDataType) {
	int ret = 0;

	ref_log_info("++ ref_HAL_SSTR_MakeSecureData(len=%d)", nSrcLen);

	if (!pSrcData) {
		ref_log_err("invalid parameter");
		return HAL_SSTR_R_GENERAL_ERROR;
	}

	// should decide to send data to which TA.
	if (pszDataType && !strcmp("general", pszDataType)) {
		// return pDstLen only if pDstData is NULL
		if (!pDstData) {
			*pDstLen = _get_len_of_securedata(strlen(TA_NAME_SESTORE), 0, IV_SIZE + nSrcLen + AES_BLOCK_SIZE - (nSrcLen % AES_BLOCK_SIZE));
		}
		else {
			// for example, common secure storage TA for "general".
			ret = secureStorage_TA_sedata(nSrcLen, pSrcData, pDstLen, pDstData, TA_CMD_DEAL_GENERAL);
			if (ret != 1) {
				return HAL_SSTR_R_GENERAL_ERROR;
			}
		}
	}
	else {
		// parse header info and get target info
		struct metainfo_sedata metainfo;

		_metainfo_init(&metainfo);
		if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
			ref_log_err("failed to parse metainfo");
			_metainfo_free(&metainfo);
			return 0;
		}

		// return pDstLen only if pDstData is NULL
		if (!pDstData && (metainfo.storageType == STORAGETYPE_WOS_SESTORE)) {
			*pDstLen = _get_len_of_securedata(metainfo.targetTaInfo_len, metainfo.keyId_len, metainfo.enc_keyblob_len);
		}
		else {
			ref_log_info("target TA info : %.*s, size = %d", metainfo.targetTaInfo_len, metainfo.pTargetTaInfo, metainfo.targetTaInfo_len);

			if (!memcmp(TA_NAME_SESTORE, metainfo.pTargetTaInfo, metainfo.targetTaInfo_len))
				ret = secureStorage_TA_sedata(nSrcLen, pSrcData, pDstLen, pDstData, TA_CMD_DEAL_SEDATA);
			else if (!memcmp("playready", metainfo.pTargetTaInfo, metainfo.targetTaInfo_len))
				ret = playready_TA_sedata(nSrcLen, pSrcData);
			else if (!memcmp("hdcp", metainfo.pTargetTaInfo, metainfo.targetTaInfo_len))
				ret = hdcp_TA_sedata(nSrcLen, pSrcData);
			else if (!memcmp("acas", metainfo.pTargetTaInfo, metainfo.targetTaInfo_len))
				ret = acas_TA_sedata(nSrcLen, pSrcData);
			else if (!memcmp("atsc", metainfo.pTargetTaInfo, metainfo.targetTaInfo_len))
				ret = atsc_TA_sedata(nSrcLen, pSrcData);
			else if (!memcmp("ecp", metainfo.pTargetTaInfo, metainfo.targetTaInfo_len))
				ret = ecp_TA_sedata(nSrcLen, pSrcData);
			else {
				ref_log_err("no available target TA");
			}

			if (ret != 1) {
				_metainfo_free(&metainfo);
				return HAL_SSTR_R_GENERAL_ERROR;
			}
		}
		_metainfo_free(&metainfo);
	}

	if (pDstLen)
		ref_log_info("-- ref_HAL_SSTR_MakeSecureData(len=%d)", *pDstLen);
	else
		ref_log_info("-- ref_HAL_SSTR_MakeSecureData");

	return HAL_SSTR_R_OK;
}

HAL_SSTR_R_T ref_HAL_SSTR_GetDataFromSecureData(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData) {
	int ret;

	ref_log_info("++ ref_HAL_SSTR_GetDataFromSecureData(len=%d)", nSrcLen);

	if (!pSrcData || !pDstLen) {
		ref_log_err("invalid parameter");
		return HAL_SSTR_R_GENERAL_ERROR;
	}

	// parsing header info.
	// might decide TA according to header info.

	struct metainfo_sedata metainfo;

	_metainfo_init(&metainfo);
	if (!_parse_metainfo(nSrcLen, pSrcData, &metainfo)) {
		ref_log_err("failed to parse metainfo");
		_metainfo_free(&metainfo);
		return 0;
	}

	// return pDstLen only if pDstData is NULL
	if (!pDstData && (metainfo.retToRee == 1)) {
		*pDstLen = metainfo.keyblob_len;
	}
	else {
		ref_log_info("target TA info : %.*s, size = %d", metainfo.targetTaInfo_len, metainfo.pTargetTaInfo, metainfo.targetTaInfo_len);

		if (!memcmp(TA_NAME_SESTORE, metainfo.pTargetTaInfo, metainfo.targetTaInfo_len)) {
			ret = secureStorage_TA_sedata(nSrcLen, pSrcData, pDstLen, pDstData, TA_CMD_READ_SECUREDATA);
			if (ret != 1) {
				_metainfo_free(&metainfo);
				return HAL_SSTR_R_GENERAL_ERROR;
			}
		}
		else {
			ref_log_err("no available target TA");
			_metainfo_free(&metainfo);
			return HAL_SSTR_R_GENERAL_ERROR;
		}
	}
	_metainfo_free(&metainfo);

	ref_log_info("-- ref_HAL_SSTR_GetDataFromSecureData(len=%d)", *pDstLen);

	return HAL_SSTR_R_OK;
}

HAL_SSTR_R_T ref_HAL_SSTR_GetHMAC(UINT32 nDataSize, UINT8 *pData, UINT8 *pKey, UINT8 *pHMAC) {
	int ret;

	ref_log_info("++ ref_HAL_SSTR_GetHMAC");

	if (!pData || !pKey || !pHMAC) {
		ref_log_err("invalid parameter");
		return HAL_SSTR_R_GENERAL_ERROR;
	}

	ret = secureStorage_TA_hmac(nDataSize, pData, pKey, pHMAC, TA_CMD_MAKE_HMAC);
	if (ret != 1) {
		return HAL_SSTR_R_GENERAL_ERROR;
	}

	ref_log_info("-- ref_HAL_SSTR_GetHMAC");

	return HAL_SSTR_R_OK;
}

HAL_SSTR_R_T ref_HAL_SSTR_VerifyHMAC(UINT32 nDataSize, UINT8 *pData, UINT8 *pKey, UINT8 *pHMAC) {
	int ret;

	ref_log_info("++ ref_HAL_SSTR_VerifyHMAC");

	if (!pData || !pKey || !pHMAC) {
		ref_log_err("invalid parameter");
		return HAL_SSTR_R_GENERAL_ERROR;
	}

	ret = secureStorage_TA_hmac(nDataSize, pData, pKey, pHMAC, TA_CMD_VERIFY_HMAC);
	if (ret != 1) {
		return HAL_SSTR_R_GENERAL_ERROR;
	}

	ref_log_info("-- ref_HAL_SSTR_VerifyHMAC");

	return HAL_SSTR_R_OK;
}
