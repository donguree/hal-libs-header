#include "util/callertracer.h"
#include "hal_sstr.h"

extern HAL_SSTR_R_T ref_HAL_SSTR_MakeSecureData(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData, char *pszDataType);
extern HAL_SSTR_R_T ref_HAL_SSTR_GetDataFromSecureData(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData);
extern HAL_SSTR_R_T ref_HAL_SSTR_GetHMAC(UINT32 nDataSize, UINT8 *pData, UINT8 *pKey, UINT8 *pHMAC);
extern HAL_SSTR_R_T ref_HAL_SSTR_VerifyHMAC(UINT32 nDataSize, UINT8 *pData, UINT8 *pKey, UINT8 *pHMAC);

HAL_SSTR_R_T HAL_SSTR_MakeSecureData(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData, char *pszDataType) {
	TRACE_ME;
	return ref_HAL_SSTR_MakeSecureData(nSrcLen, pSrcData, pDstLen, pDstData, pszDataType);
}

HAL_SSTR_R_T HAL_SSTR_GetDataFromSecureData(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData) {
	TRACE_ME;
	return ref_HAL_SSTR_GetDataFromSecureData(nSrcLen, pSrcData, pDstLen, pDstData);
}

HAL_SSTR_R_T HAL_SSTR_GetHMAC(UINT32 nDataSize, UINT8 *pData, UINT8 *pKey, UINT8 *pHMAC) {
	TRACE_ME;
	return ref_HAL_SSTR_GetHMAC(nDataSize, pData, pKey, pHMAC);
}

HAL_SSTR_R_T HAL_SSTR_VerifyHMAC(UINT32 nDataSize, UINT8 *pData, UINT8 *pKey, UINT8 *pHMAC) {
	TRACE_ME;
	//do_test();
	return ref_HAL_SSTR_VerifyHMAC(nDataSize, pData, pKey, pHMAC);
}

HAL_SSTR_R_T HAL_SSTR_GenAESKey(UINT32 nSize, UINT8 *pKey) {
	TRACE_ME;
	return HAL_SSTR_R_GENERAL_ERROR;
}

HAL_SSTR_R_T HAL_SSTR_AES_Encrypt(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData, char *pszMode, UINT8 *pKey, UINT32 nKeySize) {
	TRACE_ME;
	return HAL_SSTR_R_GENERAL_ERROR;
}

HAL_SSTR_R_T HAL_SSTR_AES_Decrypt(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData, char *pszMode, UINT8 *pKey, UINT32 nKeySize) {
	TRACE_ME;
	return HAL_SSTR_R_GENERAL_ERROR;
}

HAL_SSTR_R_T HAL_SSTR_RSA_Encrypt(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData, HAL_SSTR_RSA_PADDING_T padding, char *pszKeyType, UINT8 *pKey, UINT32 nKeySize) {
	TRACE_ME;
	return HAL_SSTR_R_GENERAL_ERROR;
}

HAL_SSTR_R_T HAL_SSTR_RSA_Decrypt(UINT32 nSrcLen, UINT8 *pSrcData, UINT32 *pDstLen, UINT8 *pDstData, HAL_SSTR_RSA_PADDING_T padding, char *pszKeyType, UINT8 *pKey, UINT32 nKeySize) {
	TRACE_ME;
	return HAL_SSTR_R_GENERAL_ERROR;
}

HAL_SSTR_R_T HAL_SSTR_RSA_Sign(UINT32 nDataSize, UINT8 *pData, UINT32 *pSigLen, UINT8 *pSig, char *pszKeyType, UINT8 *pKey, UINT32 nKeySize) {
	TRACE_ME;
	return HAL_SSTR_R_GENERAL_ERROR;
}

HAL_SSTR_R_T HAL_SSTR_RSA_Verify(UINT32 nDataSize, UINT8 *pData, UINT32 nSigLen, UINT8 *pSig, char *pszKeyType, UINT8 *pKey, UINT32 nKeySize) {
	TRACE_ME;
	return HAL_SSTR_R_GENERAL_ERROR;
}
