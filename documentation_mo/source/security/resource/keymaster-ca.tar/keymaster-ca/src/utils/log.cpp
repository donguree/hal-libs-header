#include "log.h"

#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"

#ifndef LOG_TAG
#define LOG_TAG NULL
#endif

bool CLog::m_bInitialised;
int  CLog::m_nLevel;

static const char *log_char[7] = { "[All]", "[Debug]", "[Info]", "[Warning]", "[Error]",
									"[Fatal]", "[None]" };

void CLog::Write(int nLevel, const char *szFormat, ...)
{
	time_t curTime;
	struct tm * pStrTime = NULL;

	CheckInit();

	time(&curTime);
	pStrTime = localtime( &curTime);

	if (nLevel >= m_nLevel)
	{
		va_list args;
		va_start(args, szFormat);

		if ( nLevel > CLog::Info ) {
			printf(ANSI_COLOR_RED "[%02d:%02d:%02d] \t %s", pStrTime->tm_hour, pStrTime->tm_min, pStrTime->tm_sec, LOG_TAG);
		}
		if ( nLevel > CLog::Debug )
			printf("%s ", log_char[nLevel]);
		vprintf(szFormat, args);
		printf(ANSI_COLOR_RESET "\n");
		va_end(args);
	}
}
void CLog::SetLevel(int nLevel)
{
	m_nLevel = nLevel;
	m_bInitialised = true;
}
void CLog::CheckInit()
{
	if (!m_bInitialised)
	{
		Init();
	}
}
void CLog::Init()
{
	int nDfltLevel(CLog::Debug);
	// enum { All=0, Debug, Info, Warning, Error, Fatal, None };
	SetLevel(nDfltLevel);
}


void CLog::print_bytes(const char* hdr, const uint8_t* buf, uint32_t size) {
    uint32_t i = 0;
	uint32_t cnt = 1;

	printf("[%s]\n", hdr);

	for(i = 0; i < size; i++)
	{
        printf("0x%02x ", buf[i]);
		if (cnt++ % 8 == 0) printf("\n");
	}
	printf("\n");
}

// Example - CLog::Write(CLog::Debug, "testing 1 2 3");

