/*
 * Copyright (C) 2017 GlobalLogic
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cstring>
#include <memory>
#include <new>

#include <keymaster/authorization_set.h>
#include <keymaster/keymaster_messages.h>
#include <optee_keymaster3_device.h>
#include <optee_keymaster_ipc.h>
#include <log.h>


#undef LOG_TAG
#define LOG_TAG "OpteeKeymaster_cpp"

using namespace std;
using ::keymaster::AbortOperationRequest;
using ::keymaster::AbortOperationResponse;
using ::keymaster::AddEntropyRequest;
using ::keymaster::AddEntropyResponse;
using ::keymaster::AttestKeyRequest;
using ::keymaster::AttestKeyResponse;
using ::keymaster::AuthorizationSet;
using ::keymaster::BeginOperationRequest;
using ::keymaster::BeginOperationResponse;
using ::keymaster::ExportKeyRequest;
using ::keymaster::ExportKeyResponse;
using ::keymaster::FinishOperationRequest;
using ::keymaster::FinishOperationResponse;
using ::keymaster::GenerateKeyRequest;
using ::keymaster::GenerateKeyResponse;
using ::keymaster::GetKeyCharacteristicsRequest;
using ::keymaster::GetKeyCharacteristicsResponse;
using ::keymaster::ImportKeyRequest;
using ::keymaster::ImportKeyResponse;
#ifdef CFG_IMPORT_SEC_KEY
using ::keymaster::ImportSecKeyRequest;
using ::keymaster::ImportSecKeyResponse;
#endif	//CFG_IMPORT_SEC_KEY
using ::keymaster::UpdateOperationRequest;
using ::keymaster::UpdateOperationResponse;
#ifdef CFG_ATTESTATION_PROVISIONING
using ::keymaster::DeleteAttestRequest;
using ::keymaster::DeleteAttestResponse;
using ::keymaster::AttestProvisionRequest;
using ::keymaster::AttestProvisionResponse;
#endif
using ::keymaster::V3_0::Tag;

namespace keymaster {

static inline keymaster_tag_type_t typeFromTag(const keymaster_tag_t tag) {
    return keymaster_tag_get_type(tag);
}

/*
 * legacy_enum_conversion converts enums from vector to keymaster and back. Currently, this is just a
 * cast to make the compiler happy. One of two things should happen though:
 * TODO The keymaster enums should become aliases for the vector generated enums so that we have a
 *      single point of truth. Then this cast function can go away.
 */
inline static keymaster_tag_t legacy_enum_conversion(const Tag value) {
    return keymaster_tag_t(value);
}

inline static Tag legacy_enum_conversion(const keymaster_tag_t value) {
    return Tag(value);
}

inline static keymaster_purpose_t legacy_enum_conversion(const KeyPurpose value) {
    return keymaster_purpose_t(value);
}

inline static keymaster_key_format_t legacy_enum_conversion(const KeyFormat value) {
    return keymaster_key_format_t(value);
}

inline static ErrorCode legacy_enum_conversion(const keymaster_error_t value) {
    return ErrorCode(value);
}

KmParamSet::KmParamSet(const vector<KeyParameter> &keyParams) {
    params = new keymaster_key_param_t[keyParams.size()];
    length = keyParams.size();
    for (size_t i = 0; i < keyParams.size(); ++i) {
        auto tag = legacy_enum_conversion(keyParams[i].tag);
        switch (typeFromTag(tag)) {
        case KM_ENUM:
        case KM_ENUM_REP:
            params[i] = keymaster_param_enum(tag, keyParams[i].f.integer);
            break;
        case KM_UINT:
        case KM_UINT_REP:
            params[i] = keymaster_param_int(tag, keyParams[i].f.integer);
            break;
        case KM_ULONG:
        case KM_ULONG_REP:
            params[i] = keymaster_param_long(tag, keyParams[i].f.longInteger);
            break;
        case KM_DATE:
            params[i] = keymaster_param_date(tag, keyParams[i].f.dateTime);
            break;
        case KM_BOOL:
            if (keyParams[i].f.boolValue)
                params[i] = keymaster_param_bool(tag);
            else
                params[i].tag = KM_TAG_INVALID;
            break;
        case KM_BIGNUM:
        case KM_BYTES:
            params[i] =
                keymaster_param_blob(tag, &keyParams[i].blob[0], keyParams[i].blob.size());
            break;
        case KM_INVALID:
        default:
            params[i].tag = KM_TAG_INVALID;
            /* just skip */
            break;
        }
    }
}



inline static vector<uint8_t> kmBlob2Vec(const keymaster_key_blob_t &blob) {
    vector<uint8_t> result(const_cast<unsigned char *>(blob.key_material), 
					const_cast<unsigned char *>(blob.key_material) + blob.key_material_size);
    return result;
}

inline static vector<uint8_t> kmBlob2Vec(const keymaster_blob_t &blob) {
    vector<uint8_t> result(const_cast<unsigned char *>(blob.data),
					const_cast<unsigned char *>(blob.data) + blob.data_length);
    return result;
}

inline vector<uint8_t> kmBuffer2Vec(const ::keymaster::Buffer& buf) {
    vector<uint8_t> result(const_cast<unsigned char*>(buf.peek_read()),
					const_cast<unsigned char*>(buf.peek_read()) + buf.available_read());
    return result;
}

inline static vector<vector<uint8_t>> kmCertChain2Vec(
                const keymaster_cert_chain_t *cert_chain) {
    vector<vector<uint8_t>> result;
    if (!cert_chain || cert_chain->entry_count == 0 || !cert_chain->entries)
        return result;

    result.resize(cert_chain->entry_count);
    for (size_t i = 0; i < cert_chain->entry_count; ++i)
    {
        auto &entry = cert_chain->entries[i];
        result[i] = kmBlob2Vec(entry);
    }

    return result;
}

inline vector<KeyParameter> kmParamSet2Vec(const keymaster_key_param_set_t& set) {
    vector<KeyParameter> result;
    if (set.length == 0 || set.params == nullptr) return result;

    result.resize(set.length);
    keymaster_key_param_t* params = set.params;
    for (size_t i = 0; i < set.length; ++i) {
        auto tag = params[i].tag;
      result[i].tag = legacy_enum_conversion(tag);
      switch (typeFromTag(tag)) {
      case KM_ENUM:
      case KM_ENUM_REP:
          result[i].f.integer = params[i].key_param.enumerated;
          break;
      case KM_UINT:
      case KM_UINT_REP:
          result[i].f.integer = params[i].key_param.integer;
          break;
      case KM_ULONG:
      case KM_ULONG_REP:
          result[i].f.longInteger = params[i].key_param.long_integer;
          break;
      case KM_DATE:
          result[i].f.dateTime = params[i].key_param.date_time;
          break;
      case KM_BOOL:
          result[i].f.boolValue = params[i].key_param.boolean;
          break;
      case KM_BIGNUM:
      case KM_BYTES:
	  	  result[i].blob.insert(result[i].blob.begin(),
	  	  					const_cast<unsigned char*>(params[i].key_param.blob.data),
	  	  					const_cast<unsigned char*>(params[i].key_param.blob.data) + params[i].key_param.blob.data_length);
          break;
      case KM_INVALID:
      default:
          params[i].tag = KM_TAG_INVALID;
          /* just skip */
          break;
      }
  }
    return result;
}

void addClientAndAppData(const vector<uint8_t>& clientId, const vector<uint8_t>& appData,
                            ::keymaster::AuthorizationSet* params) {
    params->Clear();
    if (clientId.size()) {
        params->push_back(::keymaster::TAG_APPLICATION_ID, clientId.data(), clientId.size());
    }
    if (appData.size()) {
        params->push_back(::keymaster::TAG_APPLICATION_DATA, appData.data(), appData.size());
    }
}

/*OpteeKeymasterDevice implementation*/

OpteeKeymaster3Device::OpteeKeymaster3Device(OpteeKeymaster* impl) : impl_(impl) {}

OpteeKeymaster3Device::~OpteeKeymaster3Device() {}


keymaster_error_t  OpteeKeymaster3Device::getHardwareFeatures(
								bool & is_secure, bool & supports_ec, bool & supports_symmetric_cryptography, 
								bool & supports_attestation, bool & supportsAllDigests, 
								string & keymasterName, string & keymasterAuthorName) {
	is_secure = supports_ec = supports_symmetric_cryptography = supports_attestation = supportsAllDigests = true;
	keymasterName = "LG Keymanager v3_0";
	keymasterAuthorName = "LG Electronics";

    return KM_ERROR_OK;
}

keymaster_error_t OpteeKeymaster3Device::addRngEntropy(const vector<uint8_t> &data) {
    if (data.size() == 0) return KM_ERROR_OK;

    AddEntropyRequest request;
    request.random_data.Reinitialize(data.data(), data.size());

    AddEntropyResponse response;
    impl_->AddRngEntropy(request, &response);

    if (response.error != KM_ERROR_OK)
        CLog::Write(CLog::Error, "Add RNG entropy failed with code %d [%x]", 
                        response.error, response.error);

    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::generateKey(const vector<KeyParameter> &keyParams,
											KeyCharacteristics* resultCharacteristics,
											vector<uint8_t> &resultKeyBlob) {
    KmParamSet params = KmParamSet(keyParams);
    return generateKey(&params, resultCharacteristics, resultKeyBlob);
}

keymaster_error_t OpteeKeymaster3Device::generateKey(const keymaster_key_param_set_t* keyParams,
											KeyCharacteristics* resultCharacteristics_,
											vector<uint8_t> &resultKeyBlob_) {
    GenerateKeyRequest request;

    KeyCharacteristics resultCharacteristics;
    vector<uint8_t> resultKeyBlob;
	
	request.key_description.Reinitialize(keyParams->params, keyParams->length);

    GenerateKeyResponse response;
    impl_->GenerateKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultKeyBlob = kmBlob2Vec(response.key_blob);
        resultCharacteristics.teeEnforced = kmParamSet2Vec(response.enforced);
        resultCharacteristics.softwareEnforced = kmParamSet2Vec(response.unenforced);
    }

	resultCharacteristics_->teeEnforced = resultCharacteristics.teeEnforced;
	resultCharacteristics_->softwareEnforced = resultCharacteristics.softwareEnforced;
	resultKeyBlob_ = resultKeyBlob;

    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::getKeyCharacteristics(const vector<uint8_t> &keyBlob,
                                    const vector<uint8_t> &clientId,
                                    const vector<uint8_t> &appData,
                                    KeyCharacteristics* resultCharacteristics) {
    GetKeyCharacteristicsRequest request;
    request.SetKeyMaterial(keyBlob.data(), keyBlob.size());
    addClientAndAppData(clientId, appData, &request.additional_params);

    GetKeyCharacteristicsResponse response;
    impl_->GetKeyCharacteristics(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultCharacteristics->teeEnforced = kmParamSet2Vec(response.enforced);
        resultCharacteristics->softwareEnforced = kmParamSet2Vec(response.unenforced);
    }
    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::importKey(const vector<KeyParameter> &params,
                                                KeyFormat keyFormat,
                                                const vector<uint8_t> &keyData,
                                                KeyCharacteristics* resultCharacteristics,
                                                vector<uint8_t> &resultKeyBlob) {
    KmParamSet p = KmParamSet(params);
    return importKey(&p, keyFormat, keyData, resultCharacteristics, resultKeyBlob);
}

keymaster_error_t  OpteeKeymaster3Device::importKey(const keymaster_key_param_set_t* params,
                                                KeyFormat keyFormat,
                                                const vector<uint8_t> &keyData,
                                                KeyCharacteristics* resultCharacteristics,
                                                vector<uint8_t> &resultKeyBlob) {
    ImportKeyRequest request;
    request.key_description.Reinitialize(params->params, params->length);
    request.key_format = legacy_enum_conversion(keyFormat);
    request.SetKeyMaterial(keyData.data(), keyData.size());

    ImportKeyResponse response;
    impl_->ImportKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultKeyBlob = kmBlob2Vec(response.key_blob);
        resultCharacteristics->teeEnforced = kmParamSet2Vec(response.enforced);
        resultCharacteristics->softwareEnforced = kmParamSet2Vec(response.unenforced);
    }
    return response.error;
}

#ifdef CFG_IMPORT_SEC_KEY
keymaster_error_t OpteeKeymaster3Device::importSecKey(const vector<KeyParameter> &params,
                                                KeyFormat keyFormat,
                                                const vector<uint8_t> &keyData,
                                                KeyCharacteristics* resultCharacteristics,
                                                vector<uint8_t> &resultKeyBlob) {
    CLog::Write(CLog::Debug, "%s %d\n", __func__, __LINE__);
    KmParamSet p = KmParamSet(params);
    return importSecKey(&p, keyFormat, keyData, resultCharacteristics, resultKeyBlob);
}

keymaster_error_t  OpteeKeymaster3Device::importSecKey(const keymaster_key_param_set_t* params,
                                                KeyFormat keyFormat,
                                                const vector<uint8_t> &keyData,
                                                KeyCharacteristics* resultCharacteristics,
                                                vector<uint8_t> &resultKeyBlob) {
    ImportSecKeyRequest request;
    request.key_description.Reinitialize(params->params, params->length);
    request.key_format = legacy_enum_conversion(keyFormat);
    request.SetKeyMaterial(keyData.data(), keyData.size());

    ImportSecKeyResponse response;
    impl_->ImportSecKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultKeyBlob = kmBlob2Vec(response.key_blob);
        resultCharacteristics->teeEnforced = kmParamSet2Vec(response.enforced);
        resultCharacteristics->softwareEnforced = kmParamSet2Vec(response.unenforced);
    }
    return response.error;
}
#endif	//CFG_IMPORT_SEC_KEY

keymaster_error_t OpteeKeymaster3Device::importWrappedKey(
											    const vector<uint8_t>& wrappedKeyData, const vector<uint8_t>& wrappingKeyBlob,
											    const vector<uint8_t>& maskingKey, const vector<KeyParameter>& unwrappingParams,
											    uint64_t passwordSid, uint64_t biometricSid, 
												KeyCharacteristics* resultCharacteristics, vector<uint8_t> &resultKeyBlob) {

    ImportWrappedKeyRequest request;
    ImportWrappedKeyResponse response;

    request.SetWrappedMaterial(wrappedKeyData.data(), wrappedKeyData.size());	
    request.SetWrappingMaterial(wrappingKeyBlob.data(), wrappingKeyBlob.size());
    request.SetMaskingKeyMaterial(maskingKey.data(), maskingKey.size());
    request.additional_params.Reinitialize(KmParamSet(unwrappingParams));
    request.password_sid = passwordSid;
    request.biometric_sid = biometricSid;

    impl_->ImportWrappedKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultKeyBlob = kmBlob2Vec(response.key_blob);
        resultCharacteristics->teeEnforced = kmParamSet2Vec(response.enforced);
        resultCharacteristics->softwareEnforced = kmParamSet2Vec(response.unenforced);
    }

    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::importWrappedData(const vector<uint8_t>& wrappedKeyData, const vector<uint8_t>& wrappingKeyBlob,
															const vector<uint8_t>& maskingKey, const keymaster_data_type_t data_type, const vector<KeyParameter>& unwrappingParams) {

    ImportWrappedDataRequest request;
    ImportWrappedDataResponse response;

    request.SetWrappedMaterial(wrappedKeyData.data(), wrappedKeyData.size());	
    request.SetWrappingMaterial(wrappingKeyBlob.data(), wrappingKeyBlob.size());
    request.SetMaskingKeyMaterial(maskingKey.data(), maskingKey.size());
    request.data_type = data_type;	
    request.additional_params.Reinitialize(KmParamSet(unwrappingParams));

    impl_->ImportWrappedData(request, &response);

    if (response.error == KM_ERROR_OK) {
		// todo nothing...?
		;
    }

    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::exportKey(KeyFormat exportFormat,
                                                const vector<uint8_t> &keyBlob,
                                                const vector<uint8_t> &clientId,
                                                const vector<uint8_t> &appData,
                                                vector<uint8_t> &resultKeyBlob) {
    ExportKeyRequest request;
    request.key_format = legacy_enum_conversion(exportFormat);
    request.SetKeyMaterial(keyBlob.data(), keyBlob.size());
    addClientAndAppData(clientId, appData, &request.additional_params);

    ExportKeyResponse response;
    impl_->ExportKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultKeyBlob.insert(resultKeyBlob.begin(), 
                            response.key_data, 
                            response.key_data + response.key_data_length);
    }
    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::attestKey(const vector<uint8_t> &keyToAttest,
                                        const vector<KeyParameter> &attestParams,
                                        vector<vector<uint8_t>> &resultCertChain) {
    KmParamSet params = KmParamSet(attestParams);
    return attestKey(keyToAttest, &params, resultCertChain);
}

keymaster_error_t OpteeKeymaster3Device::attestKey(const vector<uint8_t> &keyToAttest,
                                        const keymaster_key_param_set_t* attestParams,
                                        vector<vector<uint8_t>> &resultCertChain) {
    AttestKeyRequest request;
    request.SetKeyMaterial(keyToAttest.data(), keyToAttest.size());
    request.attest_params.Reinitialize(attestParams->params, attestParams->length);

    AttestKeyResponse response;
    impl_->AttestKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultCertChain = kmCertChain2Vec(&response.certificate_chain);
    }
    return response.error;
}

#ifdef CFG_ATTESTATION_PROVISIONING
keymaster_error_t OpteeKeymaster3Device::deleteAttestKeyCert() {
    DeleteAttestRequest request;
    DeleteAttestResponse response;
    impl_->DeleteAttestKeyCert(request, &response);
    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::setAttestationKey(keymaster_algorithm_t _algo, const vector<uint8_t>& material) {
    AttestProvisionRequest request;
    request.mAlgorithm = _algo;
    request.SetProvisionMaterial(material.data(), material.size());

    AttestProvisionResponse response;
    impl_->SetAttestationKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        CLog::Write(CLog::Error, "SetAttestationKey failed with code %d [%x]", response.error, response.error);
    }
    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::appendAttestationCertChain(keymaster_algorithm_t _algo, const vector<uint8_t>& material) {
    AttestProvisionRequest request;
    request.mAlgorithm = _algo;
    request.SetProvisionMaterial(material.data(), material.size());

    AttestProvisionResponse response;
    impl_->AppendAttestationCertChain(request, &response);

    if (response.error == KM_ERROR_OK) {
        CLog::Write(CLog::Error, "appendAttestationCertChain failed with code %d [%x]", response.error, response.error);
    }

    return response.error;
}
#endif

keymaster_error_t OpteeKeymaster3Device::upgradeKey(const vector<uint8_t> &keyBlobToUpgrade,
                                        const vector<KeyParameter> &upgradeParams,
                                        vector<uint8_t> &upgradedKey) {
    KmParamSet params = KmParamSet(upgradeParams);
    return upgradeKey(keyBlobToUpgrade, &params, upgradedKey);
}

keymaster_error_t OpteeKeymaster3Device::upgradeKey(const vector<uint8_t> &keyBlobToUpgrade,
                                        const keymaster_key_param_set_t* upgradeParams,
                                        vector<uint8_t> &upgradedKey) {
    UpgradeKeyRequest request;
    request.SetKeyMaterial(keyBlobToUpgrade.data(), keyBlobToUpgrade.size());
    request.upgrade_params.Reinitialize(upgradeParams->params, upgradeParams->length);

    UpgradeKeyResponse response;
    impl_->UpgradeKey(request, &response);

    if (response.error == KM_ERROR_OK) {
        upgradedKey = kmBlob2Vec(response.upgraded_key);
    } else {
        upgradedKey = vector<uint8_t>();
    }
    return response.error;
}
	
keymaster_error_t  OpteeKeymaster3Device::deleteKey(const vector<uint8_t> &keyBlob) {
    DeleteKeyRequest request;
    request.SetKeyMaterial(keyBlob.data(), keyBlob.size());

    DeleteKeyResponse response;
    impl_->DeleteKey(request, &response);

    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::deleteAllKeys() {
    DeleteAllKeysRequest request;
    DeleteAllKeysResponse response;
    impl_->DeleteAllKeys(request, &response);

    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::begin(keymaster_purpose_t purpose,
                                        const vector<uint8_t> &key,
                                        const vector<KeyParameter> &inParams,
                                        vector<KeyParameter> &resultParams,
                                        keymaster_operation_handle_t* op_handle) {
    KmParamSet params = KmParamSet(inParams);
    return begin(purpose, key, &params, resultParams, op_handle);
}

keymaster_error_t OpteeKeymaster3Device::begin(keymaster_purpose_t purpose,
                                        const vector<uint8_t> &key,
                                        const keymaster_key_param_set_t* inParams,
                                        vector<KeyParameter> &resultParams,
                                        keymaster_operation_handle_t* op_handle) {
    BeginOperationRequest request;
    request.purpose = purpose;
    request.SetKeyMaterial(key.data(), key.size());
    request.additional_params.Reinitialize(inParams->params, inParams->length);

    BeginOperationResponse response;
    impl_->BeginOperation(request, &response);
    if (response.error == KM_ERROR_OK) {
        *op_handle = response.op_handle;
        resultParams = kmParamSet2Vec(response.output_params);
    }

    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::update(const keymaster_operation_handle_t operationHandle, 
                                        const vector<KeyParameter> &inParams,
                                        const vector<uint8_t> &input, 
                                        vector<KeyParameter> &resultParams,
                                        vector<uint8_t> &resultBlob,
                                        size_t* input_consumed) {
    KmParamSet params = KmParamSet(inParams);
    return update(operationHandle, &params, input, resultParams, resultBlob, input_consumed);
}

keymaster_error_t OpteeKeymaster3Device::update(const keymaster_operation_handle_t operationHandle, 
                                        const keymaster_key_param_set_t* inParams,
                                        const vector<uint8_t> &input, 
                                        vector<KeyParameter> &resultParams,
                                        vector<uint8_t> &resultBlob,
                                        size_t* input_consumed) {
    UpdateOperationRequest request;
    UpdateOperationResponse response;
    uint32_t resultConsumed = 0;

    request.op_handle = operationHandle;
    request.additional_params.Reinitialize(inParams->params, inParams->length);

    size_t inp_size = input.size();
    size_t ser_size = request.SerializedSize();

    if (ser_size > OPTEE_KEYMASTER_SEND_BUF_SIZE) {
        response.error = KM_ERROR_INVALID_INPUT_LENGTH;
    } else {
        if (ser_size + inp_size > OPTEE_KEYMASTER_SEND_BUF_SIZE) {
            inp_size = OPTEE_KEYMASTER_SEND_BUF_SIZE - ser_size;
        }
        request.input.Reinitialize(input.data(), inp_size);

        impl_->UpdateOperation(request, &response);

        if (response.error == KM_ERROR_OK) {
            resultConsumed = response.input_consumed;
            resultParams = kmParamSet2Vec(response.output_params);
            resultBlob = kmBuffer2Vec(response.output);
        }
		*input_consumed = resultConsumed;
    }
    return response.error;
}

keymaster_error_t OpteeKeymaster3Device::finish(const keymaster_operation_handle_t operationHandle,
                                        const vector<KeyParameter> &inParams,
                                        const vector<uint8_t> &input,
                                        const vector<uint8_t> &signature,
                                        vector<KeyParameter> &resultParams,
                                        vector<uint8_t> &resultBlob) {
    KmParamSet params = KmParamSet(inParams);
    return finish(operationHandle, &params, input, signature, resultParams, resultBlob);
}

keymaster_error_t  OpteeKeymaster3Device::finish(const keymaster_operation_handle_t operationHandle,
                                        const keymaster_key_param_set_t* inParams,
                                        const vector<uint8_t> &input,
                                        const vector<uint8_t> &signature,
                                        vector<KeyParameter> &resultParams,
                                        vector<uint8_t> &resultBlob) {
    FinishOperationRequest request;
    request.op_handle = operationHandle;
    request.input.Reinitialize(input.data(), input.size());
    request.signature.Reinitialize(signature.data(), signature.size());
    request.additional_params.Reinitialize(inParams->params, inParams->length);

    FinishOperationResponse response;
    impl_->FinishOperation(request, &response);

    if (response.error == KM_ERROR_OK) {
        resultParams = kmParamSet2Vec(response.output_params);
        resultBlob = kmBuffer2Vec(response.output);
    }
    return response.error;
}


keymaster_error_t  OpteeKeymaster3Device::abort(const keymaster_operation_handle_t operationHandle) {
    AbortOperationRequest request;
    request.op_handle = operationHandle;

    AbortOperationResponse response;
    impl_->AbortOperation(request, &response);

    return response.error;
}

}  // namespace keymaster
