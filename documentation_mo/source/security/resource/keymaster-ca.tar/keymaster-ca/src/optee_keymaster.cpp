/*
 * Copyright (C) 2017 GlobalLogic
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include <optee_keymaster.h>
#include <optee_keymaster_ipc.h>
#include <log.h>

#include <err.h>
#include <regex.h>

#include <regex>
#include <string>

#define PROPERTY_VALUE_MAX 80 /* Value doesn't matter */
void property_get(const char* /* prop_name */, char* /* prop */, const char* /* default */) {}

#undef LOG_TAG
#define LOG_TAG "OpteeKeymaster_cpp"

namespace keymaster {

namespace {

constexpr char kPlatformVersionProp[] = "ro.build.version.release";
constexpr char kPlatformVersionRegex[] = "^([0-9]{1,2})(\\.([0-9]{1,2}))?(\\.([0-9]{1,2}))?";
constexpr size_t kMajorVersionMatch = 1;
constexpr size_t kMinorVersionMatch = 3;
constexpr size_t kSubminorVersionMatch = 5;
constexpr size_t kPlatformVersionMatchCount = kSubminorVersionMatch + 1;

constexpr char kPlatformPatchlevelProp[] = "ro.build.version.security_patch";
constexpr char kPlatformPatchlevelRegex[] = "^([0-9]{4})-([0-9]{2})-[0-9]{2}$";
constexpr size_t kYearMatch = 1;
constexpr size_t kMonthMatch = 2;
constexpr size_t kPlatformPatchlevelMatchCount = kMonthMatch + 1;

uint32_t match_to_uint32(const char* expression, const regmatch_t& match) {
    if (match.rm_so == -1)
        return 0;

    size_t len = match.rm_eo - match.rm_so;
    std::string s(expression + match.rm_so, len);
    return std::stoul(s);
}
}	// anonymous namespace

uint32_t GetOsVersion(const char* version_str) {
    regex_t regex;
    if (regcomp(&regex, kPlatformVersionRegex, REG_EXTENDED)) {
        CLog::Write(CLog::Error, "Failed to compile version regex! (%s)", kPlatformVersionRegex);
        return 0;
    }

    regmatch_t matches[kPlatformVersionMatchCount];
    int not_match =
        regexec(&regex, version_str, kPlatformVersionMatchCount, matches, 0 /* flags */);
    regfree(&regex);
    if (not_match) {
        CLog::Write(CLog::Error, "Platform version string does not match expected format.  Using version 0.");
        return 0;
    }

    uint32_t major = match_to_uint32(version_str, matches[kMajorVersionMatch]);
    uint32_t minor = match_to_uint32(version_str, matches[kMinorVersionMatch]);
    uint32_t subminor = match_to_uint32(version_str, matches[kSubminorVersionMatch]);

    return (major * 100 + minor) * 100 + subminor;
}

uint32_t GetOsVersion() {
#ifdef NEED_TO_CHECK
    char version_str[PROPERTY_VALUE_MAX];
    property_get(kPlatformVersionProp, version_str, "" /* default */);
    return GetOsVersion(version_str);
#else
	return 1;
#endif
}

uint32_t GetOsPatchlevel(const char* patchlevel_str) {
#ifdef NEED_TO_CHECK
    regex_t regex;
    if (regcomp(&regex, kPlatformPatchlevelRegex, REG_EXTENDED) != 0) {
        CLog::Write(CLog::Error, "Failed to compile platform patchlevel regex! (%s)", kPlatformPatchlevelRegex);
        return 0;
    }

    regmatch_t matches[kPlatformPatchlevelMatchCount];
    int not_match =
        regexec(&regex, patchlevel_str, kPlatformPatchlevelMatchCount, matches, 0 /* flags */);
    regfree(&regex);
    if (not_match) {
        CLog::Write(CLog::Error, "Platform patchlevel string does not match expected format.  Using patchlevel 0");
        return 0;
    }

    uint32_t year = match_to_uint32(patchlevel_str, matches[kYearMatch]);
    uint32_t month = match_to_uint32(patchlevel_str, matches[kMonthMatch]);

    if (month < 1 || month > 12) {
        CLog::Write(CLog::Error, "Invalid patch month %d", month);
        return 0;
    }
    return year * 100 + month;
#else
	return 2;
#endif
}


uint32_t GetOsPatchlevel() {
    char patchlevel_str[PROPERTY_VALUE_MAX];
    property_get(kPlatformPatchlevelProp, patchlevel_str, "" /* default */);
    return GetOsPatchlevel(patchlevel_str);
}

int OpteeKeymaster::Initialize() {
    int err;

    err = optee_keymaster_initialize();
    if (err) {
        CLog::Write(CLog::Error, "Failed to connect to optee keymaster %d", err);
        return err;
    }

    err = optee_keymaster_connect();
    if (err) {
        CLog::Write(CLog::Error, "Failed to connect to optee keymaster %d", err);
        return err;
    }

    ConfigureRequest req;
    req.os_version = GetOsVersion();
    req.os_patchlevel = GetOsPatchlevel();
    CLog::Write(CLog::Info, "os_versin : %d, patchlevel : %d\n", req.os_version, req.os_patchlevel);

    ConfigureResponse rsp;
    Configure(req, &rsp);

    if (rsp.error != KM_ERROR_OK) {
        errx(1, "Failed to configure keymaster %d", rsp.error);
    }

    return 0;
}

static inline keymaster_tag_type_t getKMtypeFromTag(const keymaster_tag_t tag) {
    return (keymaster_tag_type_t)(tag & (0xF << 28));
}


OpteeKeymaster::OpteeKeymaster() {}

OpteeKeymaster::~OpteeKeymaster() {
    optee_keymaster_disconnect();
    optee_keymaster_finalize();
}

static void ForwardCommand(enum keymaster_command command, const KeymasterMessage& req, KeymasterResponse* rsp) {
    keymaster_error_t err;
    err = optee_keymaster_call(command, req, rsp);
    if (err != KM_ERROR_OK) {
        CLog::Write(CLog::Error, "Failed to send cmd %d err: %d", command, err);
        rsp->error = err;
    }
}


void OpteeKeymaster::GetVersion(const GetVersionRequest& request, GetVersionResponse* response) {
	    ForwardCommand(KM_GET_VERSION, request, response);
}

void OpteeKeymaster::SupportedAlgorithms(const SupportedAlgorithmsRequest& request, SupportedAlgorithmsResponse* response) {
	    ForwardCommand(KM_GET_SUPPORTED_ALGORITHMS, request, response);
}

void OpteeKeymaster::SupportedBlockModes(const SupportedBlockModesRequest& request, SupportedBlockModesResponse* response) {
	    ForwardCommand(KM_GET_SUPPORTED_BLOCK_MODES, request, response);
}

void OpteeKeymaster::SupportedPaddingModes(const SupportedPaddingModesRequest& request, SupportedPaddingModesResponse* response) {
	    ForwardCommand(KM_GET_SUPPORTED_PADDING_MODES, request, response);
}

void OpteeKeymaster::SupportedDigests(const SupportedDigestsRequest& request, SupportedDigestsResponse* response) {
	    ForwardCommand(KM_GET_SUPPORTED_DIGESTS, request, response);
}

void OpteeKeymaster::SupportedImportFormats(const SupportedImportFormatsRequest& request,
                                             SupportedImportFormatsResponse* response) {
    ForwardCommand(KM_GET_SUPPORTED_IMPORT_FORMATS, request, response);
}

void OpteeKeymaster::SupportedExportFormats(const SupportedExportFormatsRequest& request,
                                             SupportedExportFormatsResponse* response) {
    ForwardCommand(KM_GET_SUPPORTED_EXPORT_FORMATS, request, response);
}

void OpteeKeymaster::AddRngEntropy(const AddEntropyRequest& request,
                                    AddEntropyResponse* response) {
    ForwardCommand(KM_ADD_RNG_ENTROPY, request, response);
}

void OpteeKeymaster::Configure(const ConfigureRequest& request, ConfigureResponse* response) {
    ForwardCommand(KM_CONFIGURE, request, response);
}

void OpteeKeymaster::GenerateKey(const GenerateKeyRequest& request, GenerateKeyResponse* response) {
    GenerateKeyRequest datedRequest(request.message_version);
    datedRequest.key_description = request.key_description;

   if (!request.key_description.Contains(TAG_CREATION_DATETIME)) {
       datedRequest.key_description.push_back(TAG_CREATION_DATETIME, java_time(time(NULL)));
  }

    ForwardCommand(KM_GENERATE_KEY, datedRequest, response);
}

void OpteeKeymaster::GetKeyCharacteristics(const GetKeyCharacteristicsRequest& request,
                                            GetKeyCharacteristicsResponse* response) {
    ForwardCommand(KM_GET_KEY_CHARACTERISTICS, request, response);
}

void OpteeKeymaster::ImportKey(const ImportKeyRequest& request, ImportKeyResponse* response) {
    ForwardCommand(KM_IMPORT_KEY, request, response);
}

#ifdef CFG_IMPORT_SEC_KEY
void OpteeKeymaster::ImportSecKey(const ImportSecKeyRequest& request, ImportSecKeyResponse* response) {
    ForwardCommand(KM_IMPORT_SEC_KEY, request, response);
}
#endif	//CFG_IMPORT_SEC_KEY

void OpteeKeymaster::ImportWrappedKey(const ImportWrappedKeyRequest& request,
                                       ImportWrappedKeyResponse* response) {
    ForwardCommand(KM_IMPORT_WRAPPED_KEY, request, response);
}

void OpteeKeymaster::ImportWrappedData(const ImportWrappedDataRequest& request,ImportWrappedDataResponse* response) {
    ForwardCommand(KM_IMPORT_WRAPPED_DATA, request, response);
}

void OpteeKeymaster::ExportKey(const ExportKeyRequest& request, ExportKeyResponse* response) {
    ForwardCommand(KM_EXPORT_KEY, request, response);
}

void OpteeKeymaster::AttestKey(const AttestKeyRequest& request, AttestKeyResponse* response) {
    ForwardCommand(KM_ATTEST_KEY, request, response);
}

void OpteeKeymaster::UpgradeKey(const UpgradeKeyRequest& request, UpgradeKeyResponse* response) {
    ForwardCommand(KM_UPGRADE_KEY, request, response);
}

void OpteeKeymaster::DeleteKey(const DeleteKeyRequest& request, DeleteKeyResponse* response) {
	    ForwardCommand(KM_DELETE_KEY, request, response);
}

void OpteeKeymaster::DeleteAllKeys(const DeleteAllKeysRequest& request,
                                    DeleteAllKeysResponse* response) {
    ForwardCommand(KM_DELETE_ALL_KEYS, request, response);
}

void OpteeKeymaster::BeginOperation(const BeginOperationRequest& request, BeginOperationResponse* response) {
    ForwardCommand(KM_BEGIN_OPERATION, request, response);
}

void OpteeKeymaster::UpdateOperation(const UpdateOperationRequest& request, UpdateOperationResponse* response) {
    ForwardCommand(KM_UPDATE_OPERATION, request, response);
}

void OpteeKeymaster::FinishOperation(const FinishOperationRequest& request, FinishOperationResponse* response) {
    ForwardCommand(KM_FINISH_OPERATION, request, response);
}

void OpteeKeymaster::AbortOperation(const AbortOperationRequest& request, AbortOperationResponse* response) {
    ForwardCommand(KM_ABORT_OPERATION, request, response);
}

#ifdef CFG_ATTESTATION_PROVISIONING
void OpteeKeymaster::DeleteAttestKeyCert(const DeleteAttestRequest& request, DeleteAttestResponse* response) {
    ForwardCommand(KM_DELETE_ATTEST_KEY_CERT, request, response);
}

void OpteeKeymaster::SetAttestationKey(const AttestProvisionRequest& request, AttestProvisionResponse* response) {
    ForwardCommand(KM_SET_ATTESTATION_KEY, request, response);
}

void OpteeKeymaster::AppendAttestationCertChain(const AttestProvisionRequest& request, AttestProvisionResponse* response) {
    ForwardCommand(KM_APPEND_ATTESTATION_CERT_CHAIN, request, response);
}
#endif

#if 0       // not support
/* Methods for Keymaster 4.0 functionality -- not yet implemented */
GetHmacSharingParametersResponse OpteeKeymaster::GetHmacSharingParameters() {
    GetHmacSharingParametersResponse response(message_version());
    response.error = KM_ERROR_UNIMPLEMENTED;
    return response;
}

ComputeSharedHmacResponse OpteeKeymaster::ComputeSharedHmac(
        const ComputeSharedHmacRequest& /* request */) {
    ComputeSharedHmacResponse response(message_version());
    response.error = KM_ERROR_UNIMPLEMENTED;
    return response;
}

VerifyAuthorizationResponse OpteeKeymaster::VerifyAuthorization(
        const VerifyAuthorizationRequest& /* request */) {
    VerifyAuthorizationResponse response(message_version());
    response.error = KM_ERROR_UNIMPLEMENTED;
    return response;
}
#endif
}  // namespace keymaster
