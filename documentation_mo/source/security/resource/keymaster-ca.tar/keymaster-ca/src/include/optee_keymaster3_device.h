/*
 **
 ** Copyright 2018, The Android Open Source Project
 **
 ** Licensed under the Apache License, Version 2.0 (the "License");
 ** you may not use this file except in compliance with the License.
 ** You may obtain a copy of the License at
 **
 **     http://www.apache.org/licenses/LICENSE-2.0
 **
 ** Unless required by applicable law or agreed to in writing, software
 ** distributed under the License is distributed on an "AS IS" BASIS,
 ** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 ** See the License for the specific language governing permissions and
 ** limitations under the License.
 */

#ifndef OPTEE_KEYMASTER3_DEVICE_H
#define OPTEE_KEYMASTER3_DEVICE_H

#include <optee_keymaster.h>
#include <hardware/types.h>

#include <vector>

namespace keymaster {

using namespace std;
using ::keymaster::V3_0::ErrorCode;
using ::keymaster::V3_0::KeyCharacteristics;
using ::keymaster::V3_0::KeyFormat;
using ::keymaster::V3_0::KeyParameter;
using ::keymaster::V3_0::KeyPurpose;


class KmParamSet : public keymaster_key_param_set_t {
  public:
	KmParamSet(const vector<KeyParameter> &keyParams);

  KmParamSet(KmParamSet&& other) noexcept
        : keymaster_key_param_set_t{other.params, other.length} {
	    other.length = 0;
	    other.params = nullptr;
	}

  KmParamSet(const KmParamSet&) = delete;
	~KmParamSet() { delete[] params; }

};

inline vector<KeyParameter> kmParamSet2Vec(const keymaster_key_param_set_t& set);

class OpteeKeymaster3Device {
  public:
    OpteeKeymaster3Device(OpteeKeymaster* impl);
    virtual ~OpteeKeymaster3Device();

	keymaster_error_t  getHardwareFeatures(bool & is_secure, bool & supports_ec, bool & supports_symmetric_cryptography, 
									bool & supports_attestation, bool & supportsAllDigests, 
									string & keymasterName, string & keymasterAuthorName);
    keymaster_error_t addRngEntropy(const vector<uint8_t> &data);
    keymaster_error_t generateKey(const vector<KeyParameter> &keyParams,
											KeyCharacteristics* resultCharacteristics,
											vector<uint8_t> &resultKeyBlob);
    keymaster_error_t generateKey(const keymaster_key_param_set_t* keyParams,
                                    KeyCharacteristics* resultCharacteristics,
                                    vector<uint8_t> &resultKeyBlob);
    keymaster_error_t getKeyCharacteristics(const vector<uint8_t> &keyBlob,
                                    const vector<uint8_t> &clientId,
                                    const vector<uint8_t> &appData,
                                    KeyCharacteristics* resultCharacteristics);
    keymaster_error_t importKey(const vector<KeyParameter> &params,
                                    KeyFormat keyFormat,
                                    const vector<uint8_t> &keyData,
                                    KeyCharacteristics* resultCharacteristics,
                                    vector<uint8_t> &resultKeyBlob);
    keymaster_error_t importKey(const keymaster_key_param_set_t* params,
                                    KeyFormat keyFormat,
                                    const vector<uint8_t> &keyData,
                                    KeyCharacteristics* resultCharacteristics,
                                    vector<uint8_t> &resultKeyBlob);
#ifdef CFG_IMPORT_SEC_KEY
    keymaster_error_t importSecKey(const vector<KeyParameter> &params,
                                    KeyFormat keyFormat,
                                    const vector<uint8_t> &keyData,
                                    KeyCharacteristics* resultCharacteristics,
                                    vector<uint8_t> &resultKeyBlob);
    keymaster_error_t importSecKey(const keymaster_key_param_set_t* params,
                                    KeyFormat keyFormat,
                                    const vector<uint8_t> &keyData,
                                    KeyCharacteristics* resultCharacteristics,
                                    vector<uint8_t> &resultKeyBlob);

#endif	//CFG_IMPORT_SEC_KEY
    keymaster_error_t exportKey(KeyFormat exportFormat,
                                    const vector<uint8_t> &keyBlob,
                                    const vector<uint8_t> &clientId,
                                    const vector<uint8_t> &appData,
                                    vector<uint8_t> &resultKeyBlob);
    keymaster_error_t attestKey(const vector<uint8_t> &keyToAttest,
                                    const vector<KeyParameter> &attestParams,
                                    vector<vector<uint8_t>> &resultCertChain);
    keymaster_error_t attestKey(const vector<uint8_t> &keyToAttest,
                                    const keymaster_key_param_set_t* attestParams,
                                    vector<vector<uint8_t>> &resultCertChain);

	keymaster_error_t importWrappedKey(const vector<uint8_t>& wrappedKeyData, const vector<uint8_t>& wrappingKeyBlob,
									const vector<uint8_t>& maskingKey, const vector<KeyParameter>& unwrappingParams,
									uint64_t passwordSid, uint64_t biometricSid, 
									KeyCharacteristics* resultCharacteristics, vector<uint8_t> &resultKeyBlob);

	keymaster_error_t importWrappedData(const vector<uint8_t>& wrappedKeyData, const vector<uint8_t>& wrappingKeyBlob,
																const vector<uint8_t>& maskingKey, const keymaster_data_type_t data_type, 
																const vector<KeyParameter>& unwrappingParams);


#ifdef CFG_ATTESTATION_PROVISIONING
    keymaster_error_t deleteAttestKeyCert();
    keymaster_error_t setAttestationKey(keymaster_algorithm_t _algo,
                                    const vector<uint8_t>& material);
    keymaster_error_t appendAttestationCertChain(keymaster_algorithm_t _algo,
                                    const vector<uint8_t>& material);
#endif
    keymaster_error_t upgradeKey(const vector<uint8_t> &keyBlobToUpgrade,
                                    const vector<KeyParameter> &upgradeParams,
                                    vector<uint8_t> &upgradedKey);
    keymaster_error_t upgradeKey(const vector<uint8_t> &keyBlobToUpgrade,
                                    const keymaster_key_param_set_t* upgradeParams,
                                    vector<uint8_t> &upgradedKey);
    keymaster_error_t deleteKey(const vector<uint8_t> &keyBlob);
    keymaster_error_t deleteAllKeys();
//	    Return<ErrorCode> destroyAttestationIds() override;
    keymaster_error_t begin(keymaster_purpose_t purpose,
                                  const vector<uint8_t> &key,
                                  const vector<KeyParameter> &inParams,
                                  vector<KeyParameter> &resultParams,
                                  keymaster_operation_handle_t* op_handle);
    keymaster_error_t begin(keymaster_purpose_t purpose,
                                  const vector<uint8_t> &key,
                                  const keymaster_key_param_set_t* inParams,
                                  vector<KeyParameter> &resultParams,
                                  keymaster_operation_handle_t* op_handle);
    keymaster_error_t finish(const keymaster_operation_handle_t operationHandle,
                                  const vector<KeyParameter> &inParams,
                                  const vector<uint8_t> &input,
                                  const vector<uint8_t> &signature,
                                  vector<KeyParameter> &resultParams,
                                  vector<uint8_t> &resultBlob); 
    keymaster_error_t finish(const keymaster_operation_handle_t op_handle,
                                  const keymaster_key_param_set_t* inParams,
                                  const vector<uint8_t> &input,
                                  const vector<uint8_t> &signature,
                                  vector<KeyParameter> &resultParams,
                                  vector<uint8_t> &resultBlob);
    keymaster_error_t update(const keymaster_operation_handle_t operationHandle, 
                                  const vector<KeyParameter> &inParams,
                                  const vector<uint8_t> &input, 
                                  vector<KeyParameter> &resultParams,
                                  vector<uint8_t> &resultBlob,
                                  size_t* input_consumed);
    keymaster_error_t update(const keymaster_operation_handle_t operationHandle, 
                                  const keymaster_key_param_set_t* inParams,
                                  const vector<uint8_t> &input, 
                                  vector<KeyParameter> &resultParams,
                                  vector<uint8_t> &resultBlob,
                                  size_t* input_consumed);
    keymaster_error_t abort(const keymaster_operation_handle_t operationHandle);


  private:
    std::unique_ptr<OpteeKeymaster> impl_;
//		int osVersion(uint32_t *in);
//		int osPatchlevel(uint32_t *in);
//		int verifiedBootState(uint8_t *in);
};


}  // namespace keymaster

#endif  // OPTEE_KEYMASTER3_DEVICE_H
