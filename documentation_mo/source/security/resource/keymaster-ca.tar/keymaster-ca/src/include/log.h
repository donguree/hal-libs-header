#ifndef __LOG_H_
#define __LOG_H_

#include <cstdio>
#include <cstdarg>
#include <stdint.h>
#include <ctime>

class CLog
{
	public:
		enum { All=0, Debug, Info, Warning, Error, Fatal, None };
		static void Write(int nLevel, const char *szFormat, ...);
		static void SetLevel(int nLevel);
		static void print_bytes(const char* hdr, const uint8_t* buf, uint32_t size);

	protected:
		static void CheckInit();
		static void Init();

	private:
		CLog();
		static bool m_bInitialised;
		static int  m_nLevel;
};

#endif // __LOG_H_

