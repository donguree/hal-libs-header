/*
 *
 * Copyright (C) 2022 LG Electronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef WRAP_H_
#define WRAP_H_


#include <tee_internal_api.h>
#include <tee_internal_api_extensions.h>
#include <utee_defines.h>

#include "ta_ca_defs.h"
#include "mbedtls_proxy.h"
#include "operations.h"
#include "attestation.h"
#include <mbedtls/x509_crt.h>

#define WRAPPED_DATA_SERVER_CERT_SIZE (256)
#define SECUREKEYWRAPPER_VERSION	0

enum keyID_type {
	SUBJECT_KEY_IDENTIFIER,
	AUTHORITY_KEY_IDENTIFIER,
};

keymaster_error_t TA_unwrap_key(const keymaster_key_blob_t * wrapped_key_blob, 
							const keymaster_key_blob_t * wrapping_key_blob,
							const keymaster_key_param_set_t * wrapping_key_params __unused, 
							const keymaster_key_blob_t * masking_key_blob,
							keymaster_key_param_set_t * wrapped_key_params, keymaster_key_format_t* wrapped_key_format,
							keymaster_blob_t * wrapped_material_blob);

keymaster_error_t TA_unwrap_data(const keymaster_blob_t * wrapped_data_blob, 
							const keymaster_key_blob_t * wrapping_key_blob,
							const keymaster_key_param_set_t * wrapping_key_params __unused,  
							const keymaster_key_blob_t * masking_key_blob,
							const keymaster_data_type_t  * data_type, 
							keymaster_blob_t * unwrapped_data_blob);
keymaster_error_t TA_send_unwrapped_data(const keymaster_data_type_t data_type, const keymaster_blob_t *unwrapped_data);

#endif
