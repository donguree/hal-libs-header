/*
 *
 * Copyright (C) 2022 LG Electronics
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
#include "mbedtls/asn1.h"
#include "mbedtls/oid.h"
#include "wrap.h"
#define AES_256			(256)

static struct wrappedkey_tags {
	keymaster_tag_t tag;
	int context;
} auth_tag_list[] = {
		{ KM_TAG_MAC_LENGTH, 1003 },
		{ KM_TAG_AUTH_TOKEN, 1002 },
		{ KM_TAG_NONCE, 1001 },
		{ KM_TAG_ASSOCIATED_DATA, 1000 },
        { KM_TAG_ATTESTATION_APPLICATION_ID, 709 },
        { KM_TAG_OS_PATCHLEVEL, 706 },
        { KM_TAG_OS_VERSION, 705 },
        { KM_TAG_ROOT_OF_TRUST, 704 },
        { KM_TAG_ROLLBACK_RESISTANT, 703 },
        { KM_TAG_ORIGIN, 702 },
        { KM_TAG_CREATION_DATETIME, 701 },
        { KM_TAG_APPLICATION_ID, 601 },
        { KM_TAG_ALL_APPLICATIONS, 600 },
        { KM_TAG_ALLOW_WHILE_ON_BODY, 506 },
        { KM_TAG_AUTH_TIMEOUT, 505 },
        { KM_TAG_USER_AUTH_TYPE, 504 },
        { KM_TAG_NO_AUTH_REQUIRED, 503 },
        { KM_TAG_USAGE_EXPIRE_DATETIME, 402 },
        { KM_TAG_ORIGINATION_EXPIRE_DATETIME, 401 },
        { KM_TAG_ACTIVE_DATETIME, 400 },
        { KM_TAG_RSA_PUBLIC_EXPONENT, 200 },
        { KM_TAG_EC_CURVE, 10 },
        { KM_TAG_MIN_MAC_LENGTH, 8 },
		{ KM_TAG_CALLER_NONCE, 7 },
		{ KM_TAG_PADDING, 6 },
        { KM_TAG_DIGEST, 5 },
      	{ KM_TAG_BLOCK_MODE, 4 },        
        { KM_TAG_KEY_SIZE, 3 },
        { KM_TAG_ALGORITHM, 2 },
        { KM_TAG_PURPOSE, 1 },
};

static keymaster_error_t parse_wrappedkey_authlist(uint8_t *p, uint8_t *end, keymaster_key_param_set_t* auth_list_param) {
	keymaster_error_t res = KM_ERROR_OK;
	int mbedtls_ret = 0;
	keymaster_tag_type_t tag_type = KM_INVALID;
	keymaster_key_param_t * param_t = NULL;
	int context = UNDEFINED;
	size_t len = 0, readlen = 0;
	size_t i = 0;
	bool matched = false;

	if(!p || !end || !auth_list_param) {
		EMSG("Invalid Parameters");
        return KM_ERROR_UNEXPECTED_NULL_POINTER;
	}

    /* Get main sequence tag */
	if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0) {
		EMSG("KeyDescription Sequence tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;	// NEED_TO_CHECK .. KM_ERROR_INVALID_TAG??
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	auth_list_param->params = TEE_Malloc(sizeof(auth_tag_list)/sizeof(auth_tag_list[0])*sizeof(keymaster_key_param_t), TEE_MALLOC_FILL_ZERO);

	if(auth_list_param->params == NULL) {
		EMSG("Failed Allocation memory");
		res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}

	auth_list_param->length = 0;

	while(p != end) {
		tag_type = KM_INVALID;
		param_t = NULL;
		matched = false;			
	
		if( (*p & (MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_CONTEXT_SPECIFIC)) ){
			context = *p++ & MBEDTLS_ASN1_TAG_VALUE_MASK;
			if(context == MBEDTLS_ASN1_TAG_VALUE_MASK) {
				context = ((p[0] ^ 0x80) << 7)+ p[1];
				p+=2;
			}

			len = *p++;
			
			for (i = 0; i<sizeof(auth_tag_list) / sizeof(auth_tag_list[0]); i++) {
				if(context != auth_tag_list[i].context)
					continue;

				matched = true;
				break;
			}

			if(matched == false) {
				EMSG("Cannot find Tag");
				res = KM_ERROR_UNSUPPORTED_TAG;
				goto EXIT;
			}

			param_t = TEE_Malloc(sizeof(keymaster_key_param_t), TEE_MALLOC_FILL_ZERO);

			if(!param_t) {
				EMSG("Failed Allocation memory");
				res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
				goto EXIT;
			}

			switch(keymaster_tag_get_type(auth_tag_list[i].tag)){
				case KM_BIGNUM:
				case KM_BYTES :{
					readlen = 0;
					if(mbedtls_asn1_get_tag(&p, p+len, &readlen, MBEDTLS_ASN1_OCTET_STRING)) {
						EMSG("tag Invalid");
						res = KM_ERROR_INVALID_ARGUMENT;	
						goto EXIT;
					}

					if (TA_is_out_of_bounds(p, p+len, readlen)) {
						EMSG("Out of input array bounds");
						res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
						goto EXIT;
					}

					uint8_t *t = TEE_Malloc(len, TEE_MALLOC_FILL_ZERO);
					
					if(!t) {
						EMSG("Failed Allocation memory");
						res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
						goto EXIT;
					}

					TEE_MemMove(t, p, len);

					param_t->key_param.blob.data_length = readlen;
					param_t->key_param.blob.data = t;

					param_t->tag = auth_tag_list[i].tag;
					TA_push_param(auth_list_param, param_t);
					break;
				}

				case KM_BOOL: {	
					readlen = 0;
					if(mbedtls_asn1_get_tag( &p, p+len, &readlen, MBEDTLS_ASN1_NULL )) {
						EMSG("tag Invalid");
						res = KM_ERROR_INVALID_ARGUMENT;	
						goto EXIT;
					}

					if(readlen!=0) {
						EMSG("tag Invalid");
						res = KM_ERROR_INVALID_ARGUMENT;	
						goto EXIT;
					}
					param_t->key_param.boolean = true;							
					param_t->tag = auth_tag_list[i].tag;
					TA_push_param(auth_list_param, param_t);
					break;
				}

				case KM_ENUM:
				case KM_UINT:
				case KM_ULONG:
				case KM_DATE:{			
					readlen = 0;
					if(mbedtls_asn1_get_tag( &p, p+len, &readlen, MBEDTLS_ASN1_INTEGER )) {
						EMSG("tag Invalid");
						res = KM_ERROR_INVALID_ARGUMENT;	
						goto EXIT;
					}

					if (TA_is_out_of_bounds(p, end, readlen)) {
						EMSG("Out of input array bounds ");
						res = KM_ERROR_INVALID_INPUT_LENGTH;
						goto EXIT;
					}

					if(readlen > 8){
						EMSG("Invalid ASN1 Integer Length %zu", readlen);
						res = KM_ERROR_INVALID_INPUT_LENGTH;	// NEED_TO_CHECK .. KM_ERROR_INVALID_TAG??
						goto EXIT;
					}

					uint64_t tmp = 0;
					for(size_t j=0; j<readlen; j++) {
						tmp = tmp << 8;
						tmp += p[j];
					}
					TEE_MemMove(&param_t->key_param, &tmp, readlen);

					param_t->tag = auth_tag_list[i].tag;
					TA_push_param(auth_list_param, param_t);
					p += readlen;

					break;
				}
				case KM_ENUM_REP:
				case KM_UINT_REP:
				case KM_ULONG_REP: {
					size_t set_len = 0;
					size_t rep_len = 0;
					if(mbedtls_asn1_get_tag(&p, p+len, &set_len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SET)) {
						EMSG("KM_TAG_PURPOSE SET tag Invalid");
						res = KM_ERROR_INVALID_ARGUMENT;	
						goto EXIT;
					}

					if (TA_is_out_of_bounds(p, end, set_len)) {
						EMSG("Out of input array bounds ");
						res = KM_ERROR_INVALID_INPUT_LENGTH;
						goto EXIT;
					}

					while(set_len != rep_len) {
						readlen = 0;

						if(mbedtls_asn1_get_tag(&p, p+len, &readlen, MBEDTLS_ASN1_INTEGER)) {
							EMSG("KM_TAG_PURPOSE SET tag Invalid");
							res = KM_ERROR_INVALID_ARGUMENT;	
							goto EXIT;
						}

						if (TA_is_out_of_bounds(p, end, readlen)) {
							EMSG("Out of input array bounds ");
							res = KM_ERROR_INVALID_INPUT_LENGTH;
							goto EXIT;
						}
											
						if(readlen > 8){
							EMSG("Invalid ASN1 Integer Length %zu", readlen);
							res = KM_ERROR_INVALID_INPUT_LENGTH;	// NEED_TO_CHECK .. KM_ERROR_INVALID_TAG??
							goto EXIT;
						}

						uint64_t tmp = 0;
						for(size_t j=0; j<readlen; j++) {
							tmp = tmp << 8;
							tmp += p[j];
						}
						TEE_MemMove(&param_t->key_param, &tmp, readlen);

						param_t->tag = auth_tag_list[i].tag;
						TA_push_param(auth_list_param, param_t);
						rep_len += 2 + readlen;
						p += readlen;
						printf("\n");
					}
					break;
				}
				
				default:{
					res = KM_ERROR_INVALID_TAG;	
					goto EXIT;
				}
			}
		} else {
			EMSG("Invalid Tag");
			res = KM_ERROR_INVALID_TAG;
			goto EXIT;
		}		
	}

EXIT:
	if(res != KM_ERROR_OK) {
		TA_free_params(auth_list_param);
		TEE_Free(param_t);
	}

	return res;
}

static keymaster_error_t aes_gcm_decrypt(const keymaster_key_blob_t * keyblob, const keymaster_blob_t * ivblob, 
										const keymaster_blob_t * aadblob, const keymaster_blob_t * tagblob, 
										const keymaster_key_blob_t * encryptedDatablob, keymaster_blob_t * plainDatablob) {
	TEE_Result res = TEE_SUCCESS;	
	keymaster_error_t km_res = KM_ERROR_OK;
	TEE_ObjectHandle tObjAES = TEE_HANDLE_NULL;
  	TEE_Attribute attr;
  	TEE_OperationHandle handle = (TEE_OperationHandle)NULL;
	uint32_t consumed = 0;
	uint8_t * pTag = NULL;
		
	if(!keyblob || !ivblob || !aadblob || !tagblob || !encryptedDatablob|| !plainDatablob) {
		EMSG("Invalid arguments");
		return KM_ERROR_INVALID_ARGUMENT;
	}

	res = TEE_AllocateTransientObject(TEE_TYPE_AES, AES_256, &tObjAES);
	if( res != TEE_SUCCESS ) {
	  EMSG("TEE_AllocateTransientObject Fail");
	  return KM_ERROR_MEMORY_ALLOCATION_FAILED;
	}

	TEE_InitRefAttribute(&attr, TEE_ATTR_SECRET_VALUE, keyblob->key_material, keyblob->key_material_size);
	res = TEE_PopulateTransientObject(tObjAES, &attr, 1);
	if (res != TEE_SUCCESS) {
		EMSG("TEE_PopulateTransientObject failed, %x", res);
		km_res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	res = TEE_AllocateOperation(&handle, TEE_ALG_AES_GCM, TEE_MODE_DECRYPT, AES_256);
	if (TEE_SUCCESS != res) {
		EMSG("Failed to alloc operation handle : 0x%x", res);
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}

	res = TEE_SetOperationKey(handle, tObjAES);
	if (res != TEE_SUCCESS) {
		EMSG("TEE_SetOperationKey failed %x", res);
		km_res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	res = TEE_AEInit(handle, ivblob->data, ivblob->data_length, tagblob->data_length*8, aadblob->data_length, encryptedDatablob->key_material_size);
	if (res != TEE_SUCCESS) {
	  EMSG("TEE_AEInit failed %x", res);
	  km_res = KM_ERROR_UNKNOWN_ERROR;
	  goto EXIT;
	}

	TEE_AEUpdateAAD(handle, aadblob->data, aadblob->data_length);

	consumed = plainDatablob->data_length;
	res = TEE_AEUpdate(handle, encryptedDatablob->key_material, encryptedDatablob->key_material_size, plainDatablob->data, &consumed);
	if (res != TEE_SUCCESS) {
		EMSG("TEE_AEUpdate failed %x", res);
		km_res = KM_ERROR_UNKNOWN_ERROR;
		goto EXIT;
	}

	pTag = TEE_Malloc(tagblob->data_length, TEE_MALLOC_FILL_ZERO);

	if(!pTag) {	
		EMSG("Failed Allocation memory");
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}

	TEE_MemMove(pTag, tagblob->data, tagblob->data_length);
	res = TEE_AEDecryptFinal(handle, encryptedDatablob->key_material + consumed, encryptedDatablob->key_material_size - consumed, plainDatablob->data, &plainDatablob->data_length, pTag, tagblob->data_length);

	if (res != TEE_SUCCESS) {
		EMSG("TEE_AEDecryptFinal failed %x", res);
		km_res = KM_ERROR_VERIFICATION_FAILED;
		goto EXIT;
	}

	plainDatablob->data_length += consumed;

EXIT:  
	if(pTag) {	
		TEE_Free(pTag);
	}

	TEE_FreeOperation(handle);
	TEE_FreeTransientObject(tObjAES);

	return km_res;
}


static keymaster_error_t ParseKeyBlob(const keymaster_key_blob_t * wrapping_key_blob, const keymaster_key_param_set_t * wrapping_key_params, 
									const keymaster_purpose_t purpose, mbedtls_pk_context * pk) {
	keymaster_error_t km_res = KM_ERROR_OK;
	
	uint32_t key_size=UNDEFINED, type=UNDEFINED;
	TEE_ObjectHandle obj_h = TEE_HANDLE_NULL;
	keymaster_key_param_set_t param_t = {.params = NULL, .length = 0};
	keymaster_algorithm_t algorithm = UNDEFINED; 
	keymaster_digest_t digest = UNDEFINED;
	keymaster_padding_t padding = UNDEFINED; 

	keymaster_block_mode_t dummyMode = UNDEFINED;
	uint32_t dummy_mac_length = UNDEFINED, dummy_min_sec = UNDEFINED;
	keymaster_blob_t dummy_nonce = {.data = NULL, .data_length=0};
	bool do_auth = false;
	uint8_t key_id[TAG_LENGTH]= {0x00,};
	uint8_t * key_material = NULL;

	key_material = TEE_Malloc(wrapping_key_blob->key_material_size, TEE_MALLOC_FILL_ZERO);

	if(!key_material) {
		EMSG("Failed Allocation memory");
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}

	// wrapping key blob 내의 key raw data 및 size와 type, param을 가져오면서 object handle까지 만들어서 가져온다.	
	km_res = TA_restore_key(key_material, wrapping_key_blob, &key_size, &type, &obj_h, &param_t);
	if (km_res != KM_ERROR_OK) {
		EMSG("failed wrapping key restore");
		goto EXIT;
	}

	// client(VTS)에서 설정한 param과 wrapping에 설정된 param의 값을 비교하면서 param 정보들을 변수화 해서 넘겨줌.
	km_res = TA_check_params(&param_t, wrapping_key_params, &algorithm, purpose, &digest, 
							&dummyMode, &padding, &dummy_mac_length, &dummy_nonce, &dummy_min_sec, &do_auth, key_id);

	if (km_res != KM_ERROR_OK) {
		EMSG("failed TA_check_params");
		goto EXIT;
	}

	// as far as I know keymaster only support RSA 2048 & SHA256 digest & OEAP MGF1(SHA1) only	
	if(algorithm != KM_ALGORITHM_RSA) {	
		EMSG("Not Supported");		
		km_res = KM_ERROR_UNSUPPORTED_ALGORITHM;
		goto EXIT;
	}

	if(key_size != 2048) {	
		EMSG("Not Supported");		
		km_res = KM_ERROR_UNSUPPORTED_KEY_SIZE;
		goto EXIT;
	}

	if(digest != KM_DIGEST_SHA_2_256) {	
		EMSG("Not Supported");		
		km_res = KM_ERROR_UNSUPPORTED_DIGEST;
		goto EXIT;
	}

	if(padding != KM_PAD_RSA_OAEP) {	
		EMSG("Not Supported");		
		km_res = KM_ERROR_UNSUPPORTED_PADDING_MODE;
		goto EXIT;
	}

	TEE_MemFill(pk, 0x00, sizeof(mbedtls_pk_context));

	if(mbedTLS_import_rsa_pk(pk, obj_h) != TEE_SUCCESS) {
		EMSG("Failed to covert to mbedctx");
		km_res = KM_ERROR_UNSUPPORTED_KEY_FORMAT;
		goto EXIT;
	}

	mbedtls_rsa_set_padding(pk->pk_ctx, MBEDTLS_RSA_PKCS_V21, MBEDTLS_MD_SHA256);

	if(mbedtls_rsa_check_privkey(pk->pk_ctx)) {
		EMSG("Failed :: mbedtls_rsa_check_privkey");
		km_res = KM_ERROR_INCOMPATIBLE_KEY_FORMAT;
		goto EXIT;
	}

EXIT:
	if(key_material) {
		TEE_Free(key_material);
		key_material = NULL;
	}

	if(obj_h != TEE_HANDLE_NULL) {
		TEE_FreeTransientObject(obj_h);
		obj_h = TEE_HANDLE_NULL;
	}

	if(km_res) {
		mbedtls_pk_free(pk);
	}

	return km_res;
}


static keymaster_error_t parse_wrappedKey_descryption(const keymaster_blob_t* key_descryption, keymaster_key_format_t* key_format, keymaster_key_param_set_t* auth_list_param) { 
	keymaster_error_t res = KM_ERROR_OK;
	int mbedtls_ret = 0;
	uint8_t * p = NULL, *end = NULL;
	size_t len = 0;

    if(!key_descryption || !key_format || !auth_list_param ) {
		EMSG("Invalid Parameters");
        res = KM_ERROR_UNEXPECTED_NULL_POINTER;
		goto EXIT;
    }

	p = key_descryption->data;
	end = key_descryption->data + key_descryption->data_length;

    /* Get main sequence tag */
	if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0) {
		EMSG("KeyDescription Sequence tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;	// NEED_TO_CHECK .. KM_ERROR_INVALID_TAG??
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	/* Get keyFormat INTEGER tag */
	if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_INTEGER)) != 0) {
		EMSG("keyFormat INTEGER tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;	// NEED_TO_CHECK .. KM_ERROR_INVALID_TAG??
		goto EXIT;
	}

	*key_format = *p;
	p += len;

	res = parse_wrappedkey_authlist(p, end, auth_list_param);
	if(res) {
		EMSG("Cannot parse wrappedkey authlist");
		goto EXIT;
	}
	
EXIT:
	if(res != KM_ERROR_OK) {
		if(auth_list_param)
			TA_free_params(auth_list_param);
		if(key_format)
			*key_format = UNDEFINED;
	}

	return res;
}

/*
SecureKeyWrapper ::= SEQUENCE {				1(tag) + 3(len)
	wrapperFormatVersion INTEGER,				1(tag) + 1(len) + 1
	encryptedTransportKey OCTET_STRING,			1(tag) + 3(len) + 256
	initializationVector OCTET_STRING,			1(tag) + 1(len) + 12

	KeyDescription ::= SEQUENCE {					1(tag) + 1(len)
		keyFormat INTEGER,							1(tag) + 1(len) + 1
		authorizationList AuthorizationList 		1(tag) + 1(len) + ???
	}

	encryptedSecretKey OCTET_STRING,			1(tag) + 1(len) + 32
	tag OCTET_STRING							1(tag) + 1(len) + 16
}
*/

static keymaster_error_t parse_wrapped_key(const keymaster_key_blob_t * wrapped_key_blob, keymaster_blob_t * iv_blob,
                                    keymaster_key_blob_t* transit_key_blob, keymaster_key_blob_t * secure_key_blob,
                                    keymaster_blob_t* tag_blob, keymaster_key_param_set_t* auth_list_param,
                                    keymaster_key_format_t* key_format, keymaster_blob_t* wrapped_key_description) {
	keymaster_error_t res = KM_ERROR_OK;
	int mbedtls_ret = 0;
	uint8_t * p = NULL, *end = NULL, *t = NULL;
	size_t len = 0;
	uint32_t wrapperFormatVersion = 0;

    if(!wrapped_key_blob || !iv_blob || !transit_key_blob || !secure_key_blob || !tag_blob || !auth_list_param || !key_format || !wrapped_key_description) {
		EMSG("Invalid Parameters");
        return KM_ERROR_UNEXPECTED_NULL_POINTER;
    }

	p = wrapped_key_blob->key_material;
	end = wrapped_key_blob->key_material + wrapped_key_blob->key_material_size;

	/* Get main sequence tag */
	if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0) {
		EMSG("Main Sequence tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	if((end - p) < 0) {
		EMSG("ASN.1 out of data");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if((size_t)(end-p) != len) {
		EMSG("Sequence length is not correct, %zu", (size_t)(end-p));
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

    /* Get wrapperFormatVersion Interger tag */
	if( (mbedtls_ret = mbedtls_asn1_get_int(&p, end, &wrapperFormatVersion)) !=0 ) {
		EMSG("wrapperFormatVersion Interger tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (wrapperFormatVersion != SECUREKEYWRAPPER_VERSION) {
		EMSG("Version %u isn't supported", wrapperFormatVersion);
		res = KM_ERROR_UNIMPLEMENTED;
		goto EXIT;
	}
	
	/* Get encryptedTransportKey OctetString tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("encryptedTransportKey OctetString tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;	// NEED_TO_CHECK ..  KM_ERROR_INVALID_TAG??
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	transit_key_blob->key_material = p;
	transit_key_blob->key_material_size = len;
	p += len;

    /* Get initializationVector OctetString tag */
    if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("initializationVector OctetString tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
    }

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	iv_blob->data = p;
	iv_blob->data_length = len;
	p += len;

	/* Get KeyDescription sequence tag */
	t = p;
	
	if((mbedtls_ret=mbedtls_asn1_get_tag(&t, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0) {
		EMSG("KeyDescription Sequence tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;	// NEED_TO_CHECK .. KM_ERROR_INVALID_TAG??
		goto EXIT;
	}
	
	if (TA_is_out_of_bounds(t, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	wrapped_key_description->data = p;
	wrapped_key_description->data_length = len+(t-p);
	p = t+len;

	/* Get encryptedSecretKey OCTET_STRING tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("encryptedSecretKey OCTET_STRING tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	secure_key_blob->key_material = p;
	secure_key_blob->key_material_size = len;
	p += len;

	/* Get tag OCTET_STRING tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("tag OCTET_STRING tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	tag_blob->data = p;
	tag_blob->data_length = len;
	p += len;

	if(p != end) {
		EMSG("Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	res = parse_wrappedKey_descryption(wrapped_key_description, key_format, auth_list_param);
	if(res != KM_ERROR_OK) {
		EMSG("failed to parse key descryption :: %d", res);
		goto EXIT;
	}

EXIT:
	if(res != KM_ERROR_OK) {		
		TEE_MemFill(iv_blob, 0x00, sizeof(*iv_blob));
		TEE_MemFill(transit_key_blob, 0x00, sizeof(*transit_key_blob));
		TEE_MemFill(secure_key_blob, 0x00, sizeof(*secure_key_blob));
		TEE_MemFill(tag_blob, 0x00, sizeof(*tag_blob));
		TA_free_params(auth_list_param);
		*key_format = UNDEFINED;
		TEE_MemFill(wrapped_key_description, 0x00, sizeof(*wrapped_key_description));
	}

	return res;
}



// wrapped_key_params : wrapped key의 authlist
// wrapped_key_format : wrapped key의 종류
// wrapped_material_blob : wrapped key가 decrypted 된 keyblob.

keymaster_error_t TA_unwrap_key(const keymaster_key_blob_t * wrapped_key_blob, const keymaster_key_blob_t * wrapping_key_blob,
							const keymaster_key_param_set_t * wrapping_key_params, const keymaster_key_blob_t * masking_key_blob,
							keymaster_key_param_set_t * wrapped_key_params, keymaster_key_format_t* wrapped_key_format,
							keymaster_blob_t * wrapped_material_blob) {

	keymaster_error_t km_res = KM_ERROR_OK;
	
    keymaster_blob_t iv_blob = {.data = NULL, .data_length = 0};
	keymaster_blob_t tag_blob = {.data = NULL, .data_length = 0};
	keymaster_blob_t  wrapped_key_description  = {.data = NULL, .data_length = 0};
    keymaster_key_blob_t secure_key_blob  = {.key_material = NULL, .key_material_size = 0};
    keymaster_key_blob_t transit_key_blob = {.key_material = NULL, .key_material_size = 0};

	mbedtls_pk_context pk = {.pk_info = NULL, .pk_ctx=NULL};
	keymaster_key_blob_t dec_transkey_blob = {.key_material = NULL, .key_material_size = 0};

	if(!wrapped_key_blob || !wrapping_key_blob || !masking_key_blob || !wrapped_key_params || !wrapped_key_format || !wrapped_material_blob ) {
		EMSG("Invalid Parameters");		
		return KM_ERROR_UNEXPECTED_NULL_POINTER;
	}

    km_res = parse_wrapped_key(wrapped_key_blob, &iv_blob, &transit_key_blob, &secure_key_blob, &tag_blob,
                              wrapped_key_params, wrapped_key_format, &wrapped_key_description);
    if (km_res!= KM_ERROR_OK)  {
		EMSG("Cannot parse wrapped data");
		goto EXIT;
    } 

/*
	km_res = TA_check_purpose(wrapping_key_params, KM_PURPOSE_WRAP_KEY);

	if(km_res != KM_ERROR_OK) {
		EMSG("Invalid wrapping key blob");
		goto EXIT;
	}
*/
	km_res = ParseKeyBlob(wrapping_key_blob, wrapping_key_params, KM_PURPOSE_WRAP_KEY, &pk);

	if(km_res != KM_ERROR_OK) {
		EMSG("Failed to Parse wrapping Blob");
		goto EXIT;
	}

	dec_transkey_blob.key_material = TEE_Malloc(AES_256, TEE_MALLOC_FILL_ZERO);

	if(!dec_transkey_blob.key_material) {
		EMSG("Failed Allocation memory");
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}
	
	dec_transkey_blob.key_material_size = AES_256;

 	km_res = mbedTLS_rsa_oaep_decrypt(pk.pk_ctx, &transit_key_blob, &dec_transkey_blob);

	if(km_res != KM_ERROR_OK) {
		EMSG("Failed to Parse wrapping Blob");
		goto EXIT;
	}

	// XOR the transit key with the masking key
	if(dec_transkey_blob.key_material_size != masking_key_blob->key_material_size) {
		EMSG("Not matched length for xor operation");
		km_res = KM_ERROR_INVALID_INPUT_LENGTH;
		goto EXIT;
	}

	for(size_t i = 0; i < dec_transkey_blob.key_material_size; i++) {
		dec_transkey_blob.key_material[i] ^= masking_key_blob->key_material[i];
	}

	wrapped_material_blob->data_length = secure_key_blob.key_material_size;
	wrapped_material_blob->data = TEE_Malloc(wrapped_material_blob->data_length, TEE_MALLOC_FILL_ZERO);
	
	if(!wrapped_material_blob->data) {
		EMSG("Failed Allocation memory");
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}
	
	km_res = aes_gcm_decrypt(&dec_transkey_blob, &iv_blob, &wrapped_key_description, &tag_blob,	&secure_key_blob, wrapped_material_blob);

	if(km_res != KM_ERROR_OK) {
		EMSG("Failed to Parse wrapping Blob");
		goto EXIT;
	}

EXIT:
	if(km_res != KM_ERROR_OK) {
		TA_free_params(wrapped_key_params);
		
		*wrapped_key_format = UNDEFINED;
	
		if(wrapped_material_blob->data) {
			TEE_Free(wrapped_material_blob->data);
			TEE_MemFill(wrapped_material_blob, 0x00, sizeof(*wrapped_material_blob));
		}
	}

	TEE_MemFill(&iv_blob, 0x00, sizeof(iv_blob));
	TEE_MemFill(&tag_blob, 0x00, sizeof(tag_blob));
	TEE_MemFill(&wrapped_key_description, 0x00, sizeof(wrapped_key_description));
	TEE_MemFill(&secure_key_blob, 0x00, sizeof(secure_key_blob));
	TEE_MemFill(&transit_key_blob, 0x00, sizeof(transit_key_blob));

	mbedtls_pk_free(&pk);

	if(dec_transkey_blob.key_material) {
		TEE_Free(dec_transkey_blob.key_material);
		TEE_MemFill(&dec_transkey_blob, 0x00, sizeof(dec_transkey_blob));
	}
	 
	return km_res;
}


/*
SecureDataWrapper ::= SEQUENCE {
    tbsWrappedData TBSWrappedData,
    signature OCTET_STRING
}
   
TBSWrappedData ::= SEQUENCE {
    wrapperFormatVersion INTEGER,
    encryptedTransportKey OCTET_STRING,
    initializationVector OCTET_STRING,
    description Description,
    secureData OCTET_STRING,
    tag OCTET_STRING
}
   
Description ::= SEQUENCE {
    dataType INTEGER,
    certificate OCTET_STRING
}
*/

static keymaster_error_t parse_wrapped_data(const keymaster_blob_t * wrapped_data_blob, keymaster_blob_t * tbs_wrapped_data,
											uint32_t *wrapperFormatVersion, keymaster_key_blob_t* transit_key_blob, 
											keymaster_blob_t * iv_blob, keymaster_blob_t * wrapped_data_description, 
											keymaster_data_type_t * data_type, keymaster_blob_t * server_cert, 
											keymaster_blob_t * encrypted_secData, keymaster_blob_t* tag_blob, keymaster_blob_t* signature) {
	keymaster_error_t res = KM_ERROR_OK;
	int mbedtls_ret = 0;
	uint8_t * p = NULL, *end = NULL, *t = NULL;
	size_t len = 0;

    if(!wrapped_data_blob || !tbs_wrapped_data || !wrapperFormatVersion || !transit_key_blob || 
		!iv_blob || !wrapped_data_description || !data_type || !server_cert || !encrypted_secData || !tag_blob) {
		EMSG("Invalid Parameters");
        return KM_ERROR_UNEXPECTED_NULL_POINTER;
    }

	p = wrapped_data_blob->data;
	end = wrapped_data_blob->data + wrapped_data_blob->data_length;

	/* Get main sequence tag */
	if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0) {
		EMSG("Main Sequence tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	tbs_wrapped_data->data = p;
	tbs_wrapped_data->data_length = wrapped_data_blob->data_length - (p - wrapped_data_blob->data) - WRAPPED_DATA_SERVER_CERT_SIZE - 4;	 // 4 : SERVER_CERT TAG+LEN

	if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0) {
		EMSG("Main Sequence tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

    /* Get wrapperFormatVersion Interger tag */
	if( (mbedtls_ret = mbedtls_asn1_get_int(&p, end, (int*)wrapperFormatVersion)) !=0 ) {
		EMSG("wrapperFormatVersion Interger tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	/* Get encryptedTransportKey OctetString tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("encryptedTransportKey OctetString tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;	// NEED_TO_CHECK ..  KM_ERROR_INVALID_TAG??
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	transit_key_blob->key_material = p;
	transit_key_blob->key_material_size = len;
	p += len;

    /* Get initializationVector OctetString tag */
    if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("initializationVector OctetString tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
    }

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}
	
	iv_blob->data = p;
	iv_blob->data_length = len;
	p += len;

	t = p;
	
	/* Get Description sequence tag */
	if((mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0) {
		EMSG("KeyDescription Sequence tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;	// NEED_TO_CHECK .. KM_ERROR_INVALID_TAG??
		goto EXIT;
	}
	
	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

    /* Get wrapped_data_description(AES GCM AAD) tag */
	wrapped_data_description->data = t;
	wrapped_data_description->data_length = len + (p-t);

    /* Get DataType Integer tag */
	if( (mbedtls_ret = mbedtls_asn1_get_int(&p, end, (int*)data_type)) !=0 ) {
		EMSG("wrapperFormatVersion Interger tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	/* Get certificate OCTET_STRING tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("encryptedSecretKey OCTET_STRING tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	server_cert->data = p;
	server_cert->data_length = len;
	p += len;

	/* Get secureData OCTET_STRING tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("tag OCTET_STRING tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	encrypted_secData->data = p;
	encrypted_secData->data_length = len;
	p += len;

	/* Get tag OCTET_STRING tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("tag OCTET_STRING tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	tag_blob->data = p;
	tag_blob->data_length = len;
	p += len;

	/* Get signature OCTET_STRING tag */
	if( (mbedtls_ret=mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_OCTET_STRING)) != 0) {
		EMSG("tag OCTET_STRING tag Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, end, len)) {
		EMSG("Out of input array bounds");
		res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	signature->data = p;
	signature->data_length = len;
	p += len;

	if(p != end) {
		EMSG("Invalid");
		res = KM_ERROR_INVALID_ARGUMENT;
	}

EXIT:
	if(res != KM_ERROR_OK) {
		TEE_MemFill(tbs_wrapped_data, 0x00, sizeof(*tbs_wrapped_data));
		TEE_MemFill(wrapperFormatVersion, 0x00, sizeof(*wrapperFormatVersion));
		TEE_MemFill(transit_key_blob, 0x00, sizeof(*transit_key_blob));
		TEE_MemFill(iv_blob, 0x00, sizeof(*iv_blob));
		TEE_MemFill(data_type, 0x00, sizeof(*data_type));
		TEE_MemFill(server_cert, 0x00, sizeof(*server_cert));
		TEE_MemFill(encrypted_secData, 0x00, sizeof(*encrypted_secData));
		TEE_MemFill(tag_blob, 0x00, sizeof(*tag_blob));
		TEE_MemFill(signature, 0x00, sizeof(*signature));
	}

	return res;
}

static keymaster_error_t findKeyID(uint8_t *p, const size_t pLen, const int keyID_type, keymaster_blob_t *pOut) {
	keymaster_error_t km_res = KM_ERROR_UNKNOWN_ERROR;
	size_t len = 0, tlen = 0;
	uint8_t *end = NULL;

	if(!p || !pOut) {
		EMSG("Invalid Parameters");
		km_res = KM_ERROR_UNEXPECTED_NULL_POINTER;
		goto EXIT;
	}

	if (TA_is_out_of_bounds(p, p+len, len)) {
		EMSG("Out of input array bounds ");
		km_res = KM_ERROR_INSUFFICIENT_BUFFER_SPACE;
		goto EXIT;
	}

	end = p + pLen;

	if((km_res = mbedtls_asn1_get_tag(&p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE)) != 0 ) {
		EMSG("Certificate V3 Extend Sequence tag Invalid");
		km_res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	while(p != end) {
		uint8_t * nextP = NULL;
		if( ( km_res = mbedtls_asn1_get_tag( &p, end, &len, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE ) ) != 0 ) {
			EMSG("Certificate V3 Extend Sequence tag Invalid");
			km_res = KM_ERROR_INVALID_ARGUMENT;
			goto EXIT;
		}

		nextP = p + len;

		if (mbedtls_asn1_get_tag(&p, end, &tlen, MBEDTLS_ASN1_OID )) {
			EMSG("Certificate V3 Extend Object Identifier tag Invalid");
			km_res = KM_ERROR_INVALID_ARGUMENT;
			goto EXIT;
		}
		if(keyID_type == SUBJECT_KEY_IDENTIFIER) {
			if(MBEDTLS_OID_SIZE(MBEDTLS_OID_SUBJECT_KEY_IDENTIFIER) != tlen ||
				TEE_MemCompare(p, MBEDTLS_OID_SUBJECT_KEY_IDENTIFIER, tlen) ) {

				p = nextP;
				continue;
			} else {
				p += tlen;

				if (mbedtls_asn1_get_tag(&p, end, &tlen, MBEDTLS_ASN1_OCTET_STRING)) {
					EMSG("Certificate V3 Extend OCTET STRING tag Invalid");
					km_res = KM_ERROR_INVALID_ARGUMENT;
					goto EXIT;
				}

				if (mbedtls_asn1_get_tag(&p, end, &tlen, MBEDTLS_ASN1_OCTET_STRING)) {
					EMSG("Cetificate V3 Extend OCTET STRING tag Invalid");
					km_res = KM_ERROR_INVALID_ARGUMENT;
					goto EXIT;
				}

				TEE_MemMove(pOut->data, p, tlen);
				pOut->data_length = tlen;
				goto EXIT;
			}
		} else if(keyID_type == AUTHORITY_KEY_IDENTIFIER) {
			if(MBEDTLS_OID_SIZE(MBEDTLS_OID_AUTHORITY_KEY_IDENTIFIER) != tlen ||
				TEE_MemCompare(p, MBEDTLS_OID_AUTHORITY_KEY_IDENTIFIER, tlen) ) {
				p = nextP;
				continue;
			} else {
				p += tlen;

				if (mbedtls_asn1_get_tag(&p, end, &tlen, MBEDTLS_ASN1_OCTET_STRING)) {
					EMSG("Certificate V3 Extend OCTET STRING tag Invalid");
					km_res = KM_ERROR_INVALID_ARGUMENT;
					goto EXIT;
				}

				if (mbedtls_asn1_get_tag(&p, end, &tlen, MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_SEQUENCE )) {
					EMSG("Certificate V3 Extend Sequence tag Invalid");
					km_res = KM_ERROR_INVALID_ARGUMENT;
					goto EXIT;
				}

				uint8_t *tmp_end = p + tlen;
				int context = 0;
				while(p != tmp_end){
					if( *p & (MBEDTLS_ASN1_CONSTRUCTED | MBEDTLS_ASN1_CONTEXT_SPECIFIC) ) {
						context = *p++ & MBEDTLS_ASN1_TAG_VALUE_MASK;
						if(context == MBEDTLS_ASN1_TAG_VALUE_MASK) {
							context = ((p[0] ^ 0x80) << 7)+ p[1];
							p+=2;
						}

						tlen = *p++;

						if(context == 0) {
							TEE_MemMove(pOut->data, p, tlen);
							pOut->data_length = tlen;
							goto EXIT;
						} else {	//index [1],[2] ...
							p+=tlen;
						}
					} else {
						EMSG("Certificate V3 Extend CONTEXT SPECIFIC tag Invalid");
						km_res = KM_ERROR_INVALID_ARGUMENT;
					}
				}
				EMSG("Can not find Authority Key Identifier");
				km_res = KM_ERROR_INVALID_ARGUMENT;
				break;
			}
		} else{
			EMSG("Invalid key identifire type (%d)", keyID_type);
			km_res = KM_ERROR_INVALID_ARGUMENT;
			goto EXIT;
		}
	}

EXIT:
	return km_res;
}

// to do change get data from storage RSARootAttCertID
static keymaster_error_t get_AttestCert(keymaster_blob_t * pOutBlob, const mbedtls_x509_buf *issuer_raw,
										keymaster_blob_t *auth_key_id, uint32_t is_v3ext) {

	keymaster_error_t km_res = KM_ERROR_UNKNOWN_ERROR;
	uint32_t type = TEE_TYPE_RSA_KEYPAIR;
	keymaster_cert_chain_t cert_chain = {.entries = NULL, .entry_count=0};
	int req_entry_num = -1;
	mbedtls_x509_crt tmp_cert;
	keymaster_blob_t sub_key_id = {.data = NULL, .data_length = 0};

	if(!pOutBlob || !issuer_raw || !auth_key_id) {
		EMSG("Invalid Parameters");
		km_res = KM_ERROR_UNEXPECTED_NULL_POINTER;
		goto EXIT;
	}

	km_res = TA_read_root_attest_cert(type,	&cert_chain);
	if(km_res != KM_ERROR_INSUFFICIENT_BUFFER_SPACE){
		EMSG("Failed to get att cert chain len, km_res = %x", km_res);
		goto EXIT;
	}

	cert_chain.entries =
		TEE_Malloc(sizeof(keymaster_blob_t) * cert_chain.entry_count, TEE_MALLOC_FILL_ZERO);

	if(!cert_chain.entries) {
		EMSG("Failed to allocate memory for chain of certificates");
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}

	km_res = TA_read_root_attest_cert(type, &cert_chain);
	if(km_res != KM_ERROR_OK) {
		EMSG("Failed to read root att cert, km_res = %x", km_res);
		goto EXIT;
	}

	for(size_t i = 0; i < cert_chain.entry_count; i++){
		if(cert_chain.entries[i].data_length){
			mbedtls_x509_crt_init( &tmp_cert );

			if((mbedtls_x509_crt_parse( &tmp_cert,
					(const unsigned char *)(cert_chain.entries[i].data),
					cert_chain.entries[i].data_length)) != 0){
				EMSG( "intermediate cert parsing is failed");
				km_res = KM_ERROR_INVALID_ARGUMENT;
				goto EXIT;
			}

			if(is_v3ext){	//if version is v3, compare auth_key_id and sub_key_id
				sub_key_id.data = TEE_Malloc(tmp_cert.v3_ext.len, TEE_MALLOC_FILL_ZERO);
				if(sub_key_id.data == NULL){
					EMSG("Failed Allocation memory");
					km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
					goto EXIT;
				}

				km_res = findKeyID(tmp_cert.v3_ext.p, tmp_cert.v3_ext.len, SUBJECT_KEY_IDENTIFIER, &sub_key_id);
				if(km_res){
					EMSG("findKeyID is failed : 0x%x", km_res);
				}else if(auth_key_id->data_length == sub_key_id.data_length){
					if(TEE_MemCompare(auth_key_id->data, sub_key_id.data, sub_key_id.data_length) == 0){
						req_entry_num = i;
						break;
					}
				}
			}

			if(tmp_cert.subject_raw.len == issuer_raw->len){	//auth_key_id and sub_key_id are mismatch
				if(TEE_MemCompare(tmp_cert.subject_raw.p,
								issuer_raw->p, issuer_raw->len) == 0){
					DMSG("CA entry number = %d", i);
					req_entry_num = i;
					break;
				}
			}
		}
	}

	if(req_entry_num != -1){
		pOutBlob->data = cert_chain.entries[req_entry_num].data;
		pOutBlob->data_length = cert_chain.entries[req_entry_num].data_length;
	} else{
		EMSG("can not find intermedate certification");
		km_res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

EXIT:
	if(cert_chain.entries) {
		TEE_Free(cert_chain.entries);
		TEE_MemFill(&cert_chain, 0x00, sizeof(cert_chain));
	}
	if(sub_key_id.data){
		TEE_Free(sub_key_id.data);
		TEE_MemFill(&sub_key_id, 0x00, sizeof(sub_key_id));
	}
	mbedtls_x509_crt_free(&tmp_cert);

	return km_res;
}

static keymaster_error_t verify_serverCert(mbedtls_x509_crt *server_crt) {
	keymaster_error_t km_res = KM_ERROR_OK;
	uint32_t flags = 0;
	mbedtls_x509_crt *cacert = NULL;
	keymaster_blob_t ICACert = {.data = NULL, .data_length = 0};
	keymaster_blob_t auth_key_id = {.data = NULL, .data_length = 0};
	uint32_t is_v3ext = true;

	if(!server_crt) {
		EMSG("Invalid Parameters");
		km_res = KM_ERROR_UNEXPECTED_NULL_POINTER;
		goto EXIT;
	}

	cacert = TEE_Malloc(sizeof( mbedtls_x509_crt ), TEE_MALLOC_FILL_ZERO );
	if(cacert == NULL){
        EMSG("alloc(%d bytes) failed", sizeof( mbedtls_x509_crt ));

        km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
        goto EXIT;
    }
	mbedtls_x509_crt_init( cacert );

	if(server_crt->v3_ext.len){
		auth_key_id.data = TEE_Malloc(server_crt->v3_ext.len, TEE_MALLOC_FILL_ZERO);
		if(auth_key_id.data == NULL){
			EMSG("Failed Allocation memory");
			km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
			goto EXIT;
		}
		km_res = findKeyID(server_crt->v3_ext.p, server_crt->v3_ext.len, AUTHORITY_KEY_IDENTIFIER, &auth_key_id);
		if(km_res){
			EMSG("findKeyID is failed : 0x%x", km_res);
			is_v3ext = false;
		}
	} else {
		is_v3ext = false;
	}

	km_res = get_AttestCert(&ICACert, &(server_crt->issuer_raw), &auth_key_id, is_v3ext);
	if(km_res){
		EMSG("get_attestCert is failed : 0x%x", km_res);
		goto EXIT;
	}

	if((mbedtls_x509_crt_parse( cacert,
					(const unsigned char *)ICACert.data,
					ICACert.data_length)) != 0){
		EMSG( "intermediate cert parsing is failed");
		km_res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	if((mbedtls_x509_crt_verify(server_crt, cacert,
								NULL, NULL, &flags,
								NULL, NULL)) != 0){
		EMSG( "mbedtls_x509_crt_verify is failed");
		km_res = KM_ERROR_VERIFICATION_FAILED;
	}

EXIT:
	if(cacert){
		mbedtls_x509_crt_free(cacert);
		TEE_Free(cacert);
	}
	if(ICACert.data){
		TEE_Free(ICACert.data);
		TEE_MemFill(&ICACert, 0x00, sizeof(ICACert));
	}
	if(auth_key_id.data){
		TEE_Free(auth_key_id.data);
		TEE_MemFill(&auth_key_id, 0x00, sizeof(auth_key_id));
	}

	return km_res;
}


static keymaster_error_t verify_signature(mbedtls_pk_context *server_pubk,
										const keymaster_blob_t* tbs_wrapped_data,
										const keymaster_blob_t* signature) {

	keymaster_error_t km_res = KM_ERROR_OK;
	uint8_t digest[32];

	if(!server_pubk || !tbs_wrapped_data || !signature) {
		EMSG("Invalid Parameters");
		km_res = KM_ERROR_UNEXPECTED_NULL_POINTER;
		goto EXIT;
	}

    if ((mbedtls_md(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256),
					tbs_wrapped_data->data,
					tbs_wrapped_data->data_length, digest)) != 0) {
        EMSG("Failed to mbedtls_md ");
        km_res = KM_ERROR_INCOMPATIBLE_DIGEST;
		goto EXIT;
    }

	if ((mbedtls_pk_verify(server_pubk, MBEDTLS_MD_SHA256,
							digest, sizeof(digest),
							signature->data, signature->data_length)) != 0) {
        EMSG("Failed to mbedtls_pk_verify");
        km_res = KM_ERROR_VERIFICATION_FAILED;
	}

EXIT:
	return km_res;
}

static keymaster_error_t verify_WrappedData(const keymaster_blob_t * tbs_wrapped_data,
										const keymaster_blob_t * server_cert, const keymaster_blob_t* signature) {
	keymaster_error_t km_res = KM_ERROR_UNKNOWN_ERROR;
	mbedtls_pk_context server_pubk = {.pk_info = NULL, .pk_ctx=NULL};
	mbedtls_x509_crt server_crt;

	if(!tbs_wrapped_data || !server_cert || !signature) {
		EMSG("Invalid Parameters");
		return KM_ERROR_UNEXPECTED_NULL_POINTER;
	}

	mbedtls_x509_crt_init(&server_crt);

	if((mbedtls_x509_crt_parse(&server_crt, (const unsigned char *)(server_cert->data),
						  server_cert->data_length)) != 0){
		EMSG( "intermediate cert parsing is failed");
		km_res = KM_ERROR_INVALID_ARGUMENT;
		goto EXIT;
	}

	km_res = verify_serverCert(&server_crt);
	if(km_res){
		EMSG("Server Certifcate verification is failed");
		goto EXIT;
	}

	km_res = verify_signature(&(server_crt.pk), tbs_wrapped_data, signature);
	if(km_res){
		EMSG("tbs_wrapped_data signature verification is failed");
		goto EXIT;
	}

EXIT:
	mbedtls_pk_free(&server_pubk);
	mbedtls_x509_crt_free(&server_crt);

	return km_res;
}

keymaster_error_t TA_unwrap_data(const keymaster_blob_t * wrapped_data_blob, const keymaster_key_blob_t * wrapping_key_blob,
							const keymaster_key_param_set_t * wrapping_key_params,
							const keymaster_key_blob_t * masking_key_blob,
							const keymaster_data_type_t  * data_type, keymaster_blob_t * unwrapped_data_blob) {
	keymaster_error_t km_res = KM_ERROR_OK;
//	TEE_Result tee_res = TEE_SUCCESS;

	keymaster_blob_t tbs_wrapped_data = {.data = NULL, .data_length = 0};
	uint32_t wrapperFormatVersion = UNDEFINED;
	keymaster_key_blob_t transit_key_blob = {.key_material = NULL, .key_material_size = 0};
	keymaster_blob_t iv_blob  = {.data = NULL, .data_length = 0};
	keymaster_blob_t server_cert = {.data = NULL, .data_length = 0};
	keymaster_blob_t encrypted_secData = {.data = NULL, .data_length = 0};
	keymaster_blob_t tag_blob = {.data = NULL, .data_length = 0};
	keymaster_blob_t signature = {.data = NULL, .data_length = 0};

	mbedtls_pk_context pk = {.pk_info = NULL, .pk_ctx=NULL};

	keymaster_blob_t wrapped_data_description = {.data= NULL, .data_length= 0};
	keymaster_key_blob_t dec_transkey_blob = {.key_material = NULL, .key_material_size = 0};
	keymaster_data_type_t target = UNDEFINED;

	if(!wrapped_data_blob || !wrapping_key_blob || !masking_key_blob || !data_type || !unwrapped_data_blob) {
		EMSG("Invalid Parameters");		
		return KM_ERROR_UNEXPECTED_NULL_POINTER;
	}

    km_res = parse_wrapped_data(wrapped_data_blob, &tbs_wrapped_data, &wrapperFormatVersion, &transit_key_blob, 
    &iv_blob, &wrapped_data_description, &target, &server_cert, &encrypted_secData, &tag_blob, &signature);

    if (km_res!= KM_ERROR_OK)  {
		EMSG("Cannot parse wrapped data");
		goto EXIT;
    }

/*
	km_res = TA_check_purpose(wrapping_key_params, KM_PURPOSE_WRAP_DATA);

	if(km_res != KM_ERROR_OK) {
		EMSG("Invalid wrapping key blob");
		goto EXIT;
	}
*/

	if(*data_type != target) {
		km_res = KM_ERROR_INCOMPATIBLE_WRAP_DATA_TYPE;
		EMSG("unmatched data type");
		goto EXIT;
	}

	km_res = verify_WrappedData(&tbs_wrapped_data, &server_cert, &signature);

    if (km_res!= KM_ERROR_OK)  {
		EMSG("Cannot verity Cert & Sig");
		goto EXIT;
    }

	km_res = ParseKeyBlob(wrapping_key_blob, wrapping_key_params, KM_PURPOSE_WRAP_DATA, &pk);

	if(km_res != KM_ERROR_OK) {
		EMSG("Failed to Parse wrapping Blob");
		goto EXIT;
	}

	dec_transkey_blob.key_material = TEE_Malloc(AES_256, TEE_MALLOC_FILL_ZERO);

	if(!dec_transkey_blob.key_material) {
		EMSG("Failed Allocation memory");
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}
	
	dec_transkey_blob.key_material_size = AES_256;

 	km_res = mbedTLS_rsa_oaep_decrypt(pk.pk_ctx, &transit_key_blob, &dec_transkey_blob);

	if(km_res != KM_ERROR_OK) {
		EMSG("Failed to Parse wrapping Blob");
		goto EXIT;
	}

	// XOR the transit key with the masking key
	if(dec_transkey_blob.key_material_size != masking_key_blob->key_material_size) {
		EMSG("Not matched length for xor operation");
		km_res = KM_ERROR_INVALID_INPUT_LENGTH;
		goto EXIT;
	}

	for(size_t i = 0; i < dec_transkey_blob.key_material_size; i++) {
		dec_transkey_blob.key_material[i] ^= masking_key_blob->key_material[i];
	}

	unwrapped_data_blob->data_length = encrypted_secData.data_length;
	unwrapped_data_blob->data = TEE_Malloc(unwrapped_data_blob->data_length, TEE_MALLOC_FILL_ZERO);
	
	if(!unwrapped_data_blob->data) {
		EMSG("Failed Allocation memory");
		km_res = KM_ERROR_MEMORY_ALLOCATION_FAILED;
		goto EXIT;
	}
	
	km_res = aes_gcm_decrypt(&dec_transkey_blob, &iv_blob, &wrapped_data_description, &tag_blob, &encrypted_secData, unwrapped_data_blob);

	if(km_res != KM_ERROR_OK) {
		EMSG("Failed to Parse wrapping Blob");
		goto EXIT;
	}

EXIT:
	if(km_res != KM_ERROR_OK) {

		if(dec_transkey_blob.key_material) {
			TEE_Free(dec_transkey_blob.key_material);
			TEE_MemFill(&dec_transkey_blob, 0x00, sizeof(dec_transkey_blob));
		}

		if(unwrapped_data_blob->data) {
			TEE_Free(unwrapped_data_blob->data);
			TEE_MemFill(unwrapped_data_blob, 0x00, sizeof(*unwrapped_data_blob));
		}

	}
	mbedtls_pk_free(&pk);

	return km_res;
}

keymaster_error_t TA_send_unwrapped_data(const keymaster_data_type_t data_type, const keymaster_blob_t *unwrapped_data) {
	keymaster_error_t km_res = KM_ERROR_OK;
	TEE_UUID ta_uuid[] = {
		{0x6dbac793, 0xf574, 0x4871, {0x8a, 0xd3, 0x04, 0x33, 0x1e, 0xc1, 0x7f, 0x24}},	//0: NETFLIX
		{0x6dbac793, 0xf574, 0x4871, {0x8a, 0xd3, 0x04, 0x33, 0x1e, 0xc1, 0x7f, 0x24}},	//1: PLAYREADY
		{0x6dbac793, 0xf574, 0x4871, {0x8a, 0xd3, 0x04, 0x33, 0x1e, 0xc1, 0x7f, 0x24}},	//2: AMAZON
		{0x6dbac793, 0xf574, 0x4871, {0x8a, 0xd3, 0x04, 0x33, 0x1e, 0xc1, 0x7f, 0x24}},	//3: DISNEY
	};
	uint32_t origin=0, CMD_READ_SECURE_DATA = 1;
	TEE_TASessionHandle session = TEE_HANDLE_NULL;
	uint32_t ntypes =TEE_PARAM_TYPES(TEE_PARAM_TYPE_MEMREF_INPUT,
									TEE_PARAM_TYPE_NONE,
									TEE_PARAM_TYPE_NONE,
									TEE_PARAM_TYPE_NONE);
	TEE_Param params[4] = {};

	if(!unwrapped_data) {
		EMSG("Invalid Parameters");
		return KM_ERROR_UNEXPECTED_NULL_POINTER;
	}

	if((data_type > KM_DATA_TYPE_DISNEY) || (data_type <KM_DATA_TYPE_NETFLIX)){
		EMSG("Invalid data type");
			return KM_ERROR_INVALID_ARGUMENT;
	}

	if ((TEE_OpenTASession(&(ta_uuid[data_type]), TEE_TIMEOUT_INFINITE,
							0, NULL, &session, &origin)) != TEE_SUCCESS) {
		EMSG("TEE_OpenTASession is failed");
		return KM_ERROR_OPERATION_CANCELLED;
	}

	TEE_MemFill(params, 0, sizeof(TEE_Param) * 4);
	params[0].memref.buffer = unwrapped_data->data;
	params[0].memref.size = unwrapped_data->data_length;

	if ((TEE_InvokeTACommand(session, 0, CMD_READ_SECURE_DATA,
							ntypes, params, &origin)) != TEE_SUCCESS) {
		EMSG("TEE_InvokeTACommand is failed");
		km_res = KM_ERROR_SECURE_HW_COMMUNICATION_FAILED;
		goto EXIT;
	}

EXIT:
	TEE_CloseTASession(session);
	session = TEE_HANDLE_NULL;

	return km_res;
}
